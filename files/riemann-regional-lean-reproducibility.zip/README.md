# Regional Lean shortening: integrated patch and row audit

Source: https://github.com/leanprover-community/riemann-hypothesis
Pinned revision: 40e56bab026552e089d7afcfeff08d2defb9c005
Original focused replays were run with Lean 4.33.1. Use the repository's pinned dependencies and prepare its build cache before attempting local Lean replay.

## Check the integrated patch

In a fresh checkout of the pinned revision:

    git apply --check /path/to/bundle/integration/Regional-from-original.patch
    git apply --numstat /path/to/bundle/integration/Regional-from-original.patch
    git apply /path/to/bundle/integration/Regional-from-original.patch
    git diff --numstat HEAD

The patch contains 47 file blocks, 853 added and 1,492 removed physical lines, net -639. The last command does not include untracked newly created files until they are staged; the patch's own --numstat covers all 47 blocks. An alternative application order, on a different clean checkout, is Previous474.patch then Regional-after474.patch, both in integration/. The earlier baseline has net -474 and the regional changes net -165. The row/lattice/family component patches document changes on intermediate trees, and are not intended to be applied on top of the completed integrated patch.

The original and replacement local row paths are enumerated by declaration in rows/row-audit.json. The source file is src/Formalism/LocalRingCardinality/CoeNeZeroOfNotMem.lean. The old local slice is 203 declaration lines excluding inter-declaration separators and the new slice is 80; nuRowOK itself moves from old L197–227 to new L210–215. This is a different measure from the repository-wide patch count; do not add the two.

Rows and family include original, focused Lean replay files and captured check logs. These document the local checks, not a complete Lean build of the integrated patch or a proof or independent verification of the Riemann hypothesis. SHA256SUMS.txt gives original SHA-256s for the unchanged files selected for this bundle.
