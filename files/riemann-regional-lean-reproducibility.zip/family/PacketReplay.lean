import MaximalPlaceTransfer

set_option autoImplicit false
namespace PacketReplay
open MaximalPlaceTransfer

variable {R X : Type} [CommRing R] [AddCommGroup X] [Module R X]
variable {QPlace W Tuple : Type}

structure Model (R X QPlace W Tuple : Type) [CommRing R] [AddCommGroup X] [Module R X] where
  prime : W → Ideal R
  prime_max : ∀ w, (prime w).IsMaximal
  all_primes : ∀ P : Ideal R, P.IsMaximal → ∃ w, prime w = P
  below : QPlace → Tuple → Prop
  base : Tuple
  empty_base : ∀ q, ¬ below q base
  exceptional : Set QPlace
  allowed : QPlace → W → Prop
  level : W → Prop
  rowL : Tuple → Submodule R X

variable (D : Model R X QPlace W Tuple)

def badQ (Q : Finset QPlace) := D.exceptional ∪ (↑Q : Set QPlace)
def okQ (Q : Finset QPlace) (w : W) := ∀ q ∈ Q, D.allowed q w
def okPT (Q : Finset QPlace) (w : W) := okQ D Q w ∨ D.level w

structure Chart (D : Model R X QPlace W Tuple) (a : Tuple) (_bad : Set QPlace) where
  valueLaw : (X → X) → Prop
  weightLaw : (X → X) → Prop
  innerLaw : (X → X) → Prop
  rationalLaw : (X → X) → Prop
  normLaw : (X → X) → Prop
  locPoly : W → X → Prop
  correctFrame : X → X
  reads : Prop

structure LocalPacket {a bad} (K : Chart D a bad) (good : W → Prop) where
  sg : True
  eW : X → X
  ptC : K.valueLaw eW
  ipP : K.innerLaw eW
  rat : K.rationalLaw eW
  weight : K.weightLaw eW
  lat : ∀ w, good w → ∀ x, localAt (D.prime w) (D.rowL a) x ↔ K.locPoly w (eW x)

structure GlobalPacket (K : Chart D D.base D.exceptional) where
  sg : True
  eW : X → X
  ptC : K.valueLaw eW
  ipP : K.innerLaw eW
  rat : K.rationalLaw eW
  weight : K.weightLaw eW
  lat : ∀ x, x ∈ D.rowL D.base ↔ ∀ w, K.locPoly w (eW x)

def valuationOfAllPlaces {K : Chart D D.base D.exceptional} {ok : W → Prop}
    (V : LocalPacket D K ok) (allGood : ∀ w, ok w) : GlobalPacket D K where
  sg := V.sg
  eW := V.eW
  ptC := V.ptC
  ipP := V.ipP
  rat := V.rat
  weight := V.weight
  lat := mem_iff_all_readings D.prime D.prime_max D.all_primes _ _ (fun w => V.lat w (allGood w))

/-- A specialization with a genuinely dependent chart indexed by the bad set;
the same dependent rewrite and final projection as in the source patch. -/
theorem base_from_family
    (family : ∀ a Q (K : Chart D a (badQ D Q)),
        (∀ q, q ∈ Q ↔ D.below q a) → (∀ q ∈ Q, True) → K.reads →
        ∃ V : LocalPacket D K (okPT D Q),
          K.normLaw V.eW ∧ V.eW = K.correctFrame)
    (K : Chart D D.base D.exceptional) (hR : K.reads) :
    ∃ V : GlobalPacket D K, K.normLaw V.eW ∧ V.eW = K.correctFrame := by
  have hfamily := family D.base ∅
  have hb : badQ D ∅ = D.exceptional := by simp [badQ]
  rw [hb] at hfamily
  obtain ⟨V,hN,hv⟩ := hfamily K (by simp [D.empty_base]) (by simp) hR
  exact ⟨valuationOfAllPlaces D V (fun _ => Or.inl (by simp [okQ])), hN, hv⟩

#print axioms valuationOfAllPlaces
#print axioms base_from_family
end PacketReplay
