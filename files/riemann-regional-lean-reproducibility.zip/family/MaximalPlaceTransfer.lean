import Mathlib.RingTheory.Ideal.Colon
import Mathlib.RingTheory.Ideal.Maximal

set_option autoImplicit false
namespace MaximalPlaceTransfer

variable {R M : Type*} [CommRing R] [AddCommGroup M] [Module R M]

/-- Membership at a prime, written with the denominator as in the manuscript. -/
def localAt (J : Ideal R) (L : Submodule R M) (x : M) : Prop :=
  ∃ s : R, s ∉ J ∧ s • x ∈ L

theorem mem_iff_all_maximal (L : Submodule R M) (x : M) :
    x ∈ L ↔ ∀ J : Ideal R, J.IsMaximal → localAt J L x := by
  constructor
  · intro hx J hJ
    exact ⟨1, fun h => hJ.ne_top ((Ideal.eq_top_iff_one J).2 h), by simpa using hx⟩
  · intro hall
    by_contra hx
    let bad := L.colon {x}
    have hbad : bad ≠ ⊤ := by
      intro e
      have h1 : (1 : R) ∈ bad := by rw [e]; trivial
      exact hx (by simpa using (Submodule.mem_colon_singleton.1 h1 : (1:R) • x ∈ L))
    obtain ⟨J, hJ, leJ⟩ := Ideal.exists_le_maximal bad hbad
    obtain ⟨s, hs, hsx⟩ := hall J hJ
    exact hs (leJ (Submodule.mem_colon_singleton.2 hsx))

/-- Relabeling of checked places need only be surjective. -/
theorem mem_iff_all_readings {W : Type*} (place : W → Ideal R)
    (maximal : ∀ w, (place w).IsMaximal)
    (complete : ∀ J : Ideal R, J.IsMaximal → ∃ w, place w = J)
    (L : Submodule R M) (reading : W → M → Prop)
    (localRule : ∀ w x, localAt (place w) L x ↔ reading w x) (x : M) :
    x ∈ L ↔ ∀ w, reading w x := by
  rw [mem_iff_all_maximal]
  constructor
  · exact fun h w => (localRule w x).mp (h _ (maximal w))
  · intro h J hJ
    obtain ⟨w, rfl⟩ := complete J hJ
    exact (localRule w x).mpr (h w)

/-- Omitting any one maximal ideal admits a false global reading, already for x=1 in the base ring. -/
theorem missing_place_fools_every_other_check (P : Ideal R) (hP : P.IsMaximal) :
    (1 : R) ∉ P ∧ ∀ J : Ideal R, J.IsMaximal → P ≠ J → localAt J P (1:R) := by
  refine ⟨fun h => hP.ne_top ((Ideal.eq_top_iff_one P).2 h), ?_⟩
  intro J hJ hne
  have bad : ¬ (P ≤ J) := fun h => hne (hP.eq_of_le hJ.ne_top h)
  obtain ⟨s, hsP, hsJ⟩ := Set.not_subset.mp bad
  exact ⟨s, hsJ, by simpa using hsP⟩

/-- Completeness is exactly the condition for every integral membership problem
to be decided by these places. Ideals of R and x=1 already test necessity. -/
theorem exact_coverage_criterion {W : Type*} (place : W → Ideal R)
    (maximal : ∀ w, (place w).IsMaximal) :
    (∀ P : Ideal R, P.IsMaximal → ∃ w, place w = P) ↔
      ∀ I : Ideal R, (1 : R) ∈ I ↔ ∀ w, localAt (place w) I (1:R) := by
  classical
  constructor
  · intro complete I
    exact mem_iff_all_readings place maximal complete I
      (fun w y => localAt (place w) I y) (fun _ _ => Iff.rfl) 1
  · intro detect P hP
    by_contra missing
    obtain ⟨hn, hall⟩ := missing_place_fools_every_other_check P hP
    apply hn
    apply (detect P).mpr
    exact fun w => hall _ (maximal w) (fun h => missing ⟨w, h.symm⟩)

/-- A compressed witness contains the unchanged field proofs and a single alignment of polynomial values. -/
structure LocalRows (W Y : Type*) (x : M → Y) (J : W → Ideal R) (L : Submodule R M)
    (Reading : W → Y → Prop) (rowWeight inner rational norm : (M → Y) → Prop) where
  value : M → Y
  pinned : value = x
  sg : rowWeight value
  ip : inner value
  rat : rational value
  local_reading : ∀ w y, localAt (J w) L y ↔ Reading w (value y)
  norm_tie : norm value

structure GlobalRows (W Y : Type*) (x : M → Y) (L : Submodule R M)
    (Reading : W → Y → Prop) (rowWeight inner rational norm : (M → Y) → Prop) where
  value : M → Y
  pinned : value = x
  sg : rowWeight value
  ip : inner value
  rat : rational value
  global_reading : ∀ y, y ∈ L ↔ ∀ w, Reading w (value y)
  norm_tie : norm value

def recover {W Y : Type*} {x : M → Y} {J : W → Ideal R} {L : Submodule R M}
    {Reading : W → Y → Prop} {rowWeight inner rational norm : (M → Y) → Prop}
    (maximal : ∀ w, (J w).IsMaximal) (complete : ∀ P : Ideal R, P.IsMaximal → ∃ w, J w = P)
    (V : LocalRows W Y x J L Reading rowWeight inner rational norm) :
    GlobalRows W Y x L Reading rowWeight inner rational norm :=
  ⟨V.value, V.pinned, V.sg, V.ip, V.rat,
   mem_iff_all_readings J maximal complete L (fun w y => Reading w (V.value y)) V.local_reading,
   V.norm_tie⟩

#print axioms mem_iff_all_maximal
#print axioms mem_iff_all_readings
#print axioms missing_place_fools_every_other_check
#print axioms exact_coverage_criterion
#print axioms recover
end MaximalPlaceTransfer
