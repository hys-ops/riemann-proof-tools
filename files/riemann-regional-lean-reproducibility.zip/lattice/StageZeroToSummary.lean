import Formalism.SharpRestriction.AdmissibleParameterJoins.DIVfromGLo
import Formalism.LocalToGlobal.GlobalTheory.GL6.CongruenceNoKernelOfHeckeRamified

noncomputable section
namespace Formalism.MainNotions.J
open Formalism.BasicNotions Formalism.L2.GlobalTheoryTheory.LocalLatticeBases Finset

theorem sum_first {k : ℕ} (hk : 0 < k) (row : Fin k → ℝ) {A Sc : ℝ}
    (hhead : row ⟨0,hk⟩ ≤ A) (ho : ∀ i : Fin k, i.val ≠ 0 → row i ≤ Sc)
    (hSc : 0 ≤ Sc) : (∑ i, row i) ≤ A+k*Sc := by
  classical
  let z : Fin k := ⟨0,hk⟩
  have hbound := Finset.sum_le_card_nsmul (Finset.univ.erase z) row Sc
    (fun i hi => ho i (fun h => (Finset.mem_erase.mp hi).1 (Fin.ext h)))
  have hcard : (Finset.univ.erase z).card ≤ k := by
    simpa using Finset.card_le_card (Finset.erase_subset z (Finset.univ : Finset (Fin k)))
  rw [← Finset.add_sum_erase Finset.univ _ (Finset.mem_univ z), nsmul_eq_mul] at *
  exact add_le_add hhead (hbound.trans (mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) hSc))

theorem slot_bound {k a b Sc B tr : ℝ} (hk : 0 < k) (ha : 0 ≤ a)
    (htrace : tr ≤ 2*a+k*Sc) (hb : B ≤ 2*b) (hSc : 2*Sc ≤ b) (hsz : 2*k ≤ b) :
    tr/k+B+(k-1) ≤ 3*(a/k+b) := by
  have hm := div_le_div_of_nonneg_right htrace hk.le
  rw [add_div,mul_div_cancel_left₀ _ hk.ne',mul_div_assoc] at hm
  linarith [div_nonneg ha hk.le]

theorem ratio_bound {k m t : ℕ} (hm : 2 ≤ m) (ht : k ≤ t) :
    2*k ≤ k+m*(t+1) := by
  have h := Nat.le_mul_of_pos_left (t+1) (by omega : 0 < m)
  omega

theorem pageZero_slot_three {D : D7} {L : SizeData₂ D} {Cn cL : ℝ} (hcL : 1 ≤ cL)
    (hN : NumsL D L Cn cL) (hW : WtsL D L Cn) (u : D.what₂.Word)
    (τ : D.what₂.Tau) (ht : τ ∈ topsOf D.host D.eTau) :
    product_first_zeroth_parts.stageZeroCost D u τ ≤ 3*(L.sc.a/D.R.k+L.sc.b') := by
  classical
  have hp := (hW u τ).2.1 (show flipTwoThree.IsTop D τ from (Finset.mem_filter.mp ht).2)
  have hn := GlobalTheoryTheory.Alc.nums hcL u hN
  have hk : 0 < D.R.k := by have := D.R.m_add_three_le_k; omega
  have hzero : D.R.N 0 = D.R.k := by simp [Ranks.N]
  have hco (i : Fin (D.R.N 0)) : (((D.fm u).lam 0 τ).w i : ℝ) = (flipTwoThree.lamCol D u τ i.val : ℝ) := by
    rw [lam_entryR D u 0 (Nat.zero_le _) τ i]
    simp [flipTwoThree.lamLiftN, (show i.val < D.R.k by simpa [hzero] using i.isLt)]
  have hsc : 0 ≤ L.Sc := by linarith [hn.2.2.2.2.2.1]
  let row : Fin (D.R.N 0) → ℝ := fun i => ((D.fm u).lam 0 τ).w i
  have hm : ∀ i : Fin (D.R.N 0), i.val ≠ 0 → row i ≤ L.Sc := by
    intro i hi
    rw [show row i = _ from hco i]
    by_cases hz : i.val < D.R.k-1
    · exact (hp.2.2.2.2 i.val (Nat.pos_of_ne_zero hi) hz).2
    · have hi' : i.val < D.R.k := by simpa [hzero] using i.isLt
      rw [show i.val = D.R.k-1 by omega]
      linarith [hp.2.2.1,hn.2.2.2.1]
  have hhead : row ⟨0,by omega⟩ ≤ 2*L.sc.a := (hco _).le.trans hp.2.1
  have htr := sum_first (by omega : 0 < D.R.N 0) row hhead hm hsc
  have hreal : (D.R.N 0 : ℝ) = D.R.k := by exact_mod_cast hzero
  rw [hreal] at htr
  have hcast : (product_first_zeroth_parts.wsum ((D.fm u).lam 0 τ) : ℝ) = ∑ i, row i := by
    simp [row,product_first_zeroth_parts.wsum]
  have htr' : (product_first_zeroth_parts.wsum ((D.fm u).lam 0 τ) : ℝ) ≤ 2*L.sc.a+D.R.k*L.Sc := by
    rw [hcast]
    exact htr
  have hrank := ratio_bound D.R.two_le_m (show D.R.k ≤ D.R.t by have := D.R.rank_add_five_le; have := D.R.two_le_m; omega)
  have h2 : (2:ℝ)*D.R.k ≤ D.R.N D.R.m := by exact_mod_cast hrank
  have hbot := (bTop_eq D u τ).le.trans hp.2.2.2.1.le
  have hpos : 0 < L.sc.a := mul_pos (by linarith [L.sc.one_lt_alt]) (Real.exp_pos _)
  unfold product_first_zeroth_parts.stageZeroCost
  rw [Nat.cast_sub (by omega : 1 ≤ D.R.k),Nat.cast_one]
  exact slot_bound (by exact_mod_cast hk) hpos.le htr' hbot hn.2.2.2.1 (h2.trans hn.2.2.1)

theorem stageZero_slots_three {D : D7} {L : SizeData₂ D} {Cn cL : ℝ} (hcL : 1 ≤ cL)
    (hN : NumsL D L Cn cL) (hW : WtsL D L Cn) (u : D.what₂.Word) (w : D.what₂.places.Pl) :
    ∑ v ∈ product_first_zeroth_parts.VV D u w,
      product_first_zeroth_parts.stageZeroCost D u ((D.fm u).tauOf w v) ≤
        3 * LocalQuadraticParts.nTT D * (L.sc.a/D.R.k+L.sc.b') := by
  classical
  have hq : 0 ≤ 3 * (L.sc.a/D.R.k+L.sc.b') := by
    have h := (nums_basic hcL u hN).2.2.1
    have ha : 0 < L.sc.a := mul_pos (by linarith [L.sc.one_lt_alt]) (Real.exp_pos _)
    positivity
  have h := Finset.sum_le_card_nsmul (product_first_zeroth_parts.VV D u w)
    (fun v => product_first_zeroth_parts.stageZeroCost D u ((D.fm u).tauOf w v))
    (3*(L.sc.a/D.R.k+L.sc.b')) (fun v hv => pageZero_slot_three hcL hN hW u _ (product_first_zeroth_parts.mem_VV hv).2)
  rw [nsmul_eq_mul] at h
  refine h.trans ?_
  unfold LocalQuadraticParts.nTT
  have hcard : ((product_first_zeroth_parts.VV D u w).card : ℝ) ≤ (D.host.TT.card : ℝ) := by
    exact_mod_cast card_VV_le D u w
  linarith only [mul_le_mul_of_nonneg_right hcard hq,
    show (D.host.TT.card:ℝ)*(3*(L.sc.a/D.R.k+L.sc.b'))=3*(D.host.TT.card:ℝ)*(L.sc.a/D.R.k+L.sc.b') by ring]

/-- The existing level-prime conclusion from the page-zero inputs of the minimal construction. -/
theorem original_summary_from_pageZero {D : D7} {L : SizeData₂ D} {Cn cL : ℝ} (hcL : 1 ≤ cL)
    (hN : NumsL D L Cn cL) (hW : WtsL D L Cn) (hBasic : LevelPrimeBasicClauses D)
    (hNu : DV.NuDef D L) (hAtT : NuAtTDef D L)
    (hSet : ∀ u, product_first_zeroth_parts.HidaSetting D u)
    (hB : ∀ u, SecondBranchInclusionLength D u)
    (hI : ∀ u, HeckeIntegralLevelZero D u) (hR : ∀ u, HeckeRamifiedLevelZero D u) :
    LocalQuadraticParts.adm26 L 12 := by
  simpa only [show (4:ℝ)*3=12 by norm_num] using
    levelPrime_summary_from_budget D L 3 hBasic _
      (fun u => congruence_no_kernel_trace (hSet u) (hB u) (hI u) (hR u))
      hNu hAtT (locSpan D) (lenAtT D L hAtT) (fun u w _ => stageZero_slots_three hcL hN hW u w) hSet (by norm_num)

end Formalism.MainNotions.J
