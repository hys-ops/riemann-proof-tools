import Mathlib.Data.Real.Basic
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Combinatorics.Young.YoungDiagram
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Finset.Lattice.Fold
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.LinearCombination
open Finset
noncomputable section
namespace Formalism.BasicNotions
structure Ranks where
  GG : Type
  k : ℕ
  m : ℕ
  t : ℕ
  k_even : Even k
  m_even : Even m
  t_odd : Odd t
  two_le_m : 2 ≤ m
  m_add_three_le_k : m + 3 ≤ k
abbrev Ranks.Psi (R : Ranks) := {_g : R.GG // True}
namespace Ranks
variable (R : Ranks)
def N (j : ℕ) : ℕ := R.k + j * (R.t + 1)

end Ranks
theorem Ranks.blk_lt (R : Ranks) {j : ℕ} (hj : j ≤ R.m) (i : Fin (R.N j)) (h : ¬ i.1 < R.k) :
    (i.1 - R.k) / (R.t + 1) < R.m := by
  have hi : i.1 < R.k + j * (R.t + 1) := i.2
  have hlt : i.1 - R.k < R.m * (R.t + 1) :=
    lt_of_lt_of_le (by omega) (Nat.mul_le_mul_right _ hj)
  exact (Nat.div_lt_iff_lt_mul (Nat.succ_pos _)).mpr hlt

def rhoVec (N : ℕ) (i : Fin N) : ℚ := ((N : ℚ) - 1) / 2 - (i : ℚ)

def hcToWeightQ {N : ℕ} (hc : Fin N → ℚ) : Fin N → ℚ := fun i => hc i - rhoVec N i

def wG (R : Ranks) (ej : ℚ) (j : ℕ) : ℚ := ej - (R.k : ℚ) / 2 - (2 * (j : ℚ) - 1) * ((R.t : ℚ) + 1) / 2


structure HCParam (R : Ranks) where
  u : Fin R.k → ℚ
  v : Fin (R.k - 1) → ℚ
  b : Fin R.m → ℚ
  e : Fin R.m → ℚ

  u_gt_v : ∀ i : Fin (R.k - 1), v i < u ⟨i.1, by omega⟩
  v_gt_u : ∀ i : Fin (R.k - 1), u ⟨i.1 + 1, by omega⟩ < v i

  u_last_gt : ∀ (h : 0 < R.k) (h' : 0 < R.m), -b ⟨0, h'⟩ < u ⟨R.k - 1, by omega⟩

  gap_be : ∀ j : Fin R.m, ((R.t : ℚ) + 3) / 2 ≤ e j - b j

  gap_eb : ∀ j : Fin R.m, ∀ h : j.1 + 1 < R.m, ((R.t : ℚ) + 3) / 2 ≤ b ⟨j.1 + 1, h⟩ - e j

  e_int : ∀ j : Fin R.m, ∃ z : ℤ, e j = z

  u_half : ∀ i : Fin R.k, ∃ z : ℤ, u i = z + 1 / 2
  v_int : ∀ i : Fin (R.k - 1), ∃ z : ℤ, v i = z
  b_int : ∀ j : Fin R.m, ∃ z : ℤ, b j = z

structure DomWeight (n : ℕ) where
  w : Fin n → ℤ
  anti : Antitone w
structure MemberForms (R : Ranks) (Tau : Type) (hc : Tau → HCParam R) where
  lam : ∀ j, Tau → DomWeight (R.N j)

  lam_eq : ∀ j (hj : j ≤ R.m) τ (i : Fin (R.N j)), ((lam j τ).w i : ℚ) =
    if h : i.1 < R.k then hcToWeightQ (hc τ).u ⟨i.1, h⟩
    else -wG R ((hc τ).e ⟨(i.1 - R.k) / (R.t + 1), R.blk_lt hj i h⟩) ((i.1 - R.k) / (R.t + 1) + 1)


structure What where
  Word : Type
  Tau : Type
  [tauFin : Fintype Tau]
attribute [instance] What.tauFin
structure Host (G : Type) where
  thickPlaces : Finset G
  topPlaces : Finset G
structure D7 where
  R : Ranks
  what₂ : What
  hc : what₂.Tau → HCParam R
  hcW : what₂.Word → what₂.Tau → HCParam R
  hcW_e : ∀ u τ, (hcW u τ).e = (hc τ).e
  fm : ∀ u : what₂.Word, MemberForms R what₂.Tau (hcW u)
  host : Host R.GG
  eTau : what₂.Tau ≃ R.Psi

namespace DV
def wSz (D : D7) (j : ℕ) (ρ : D.what₂.Tau) : ℝ :=
  if h : 1 ≤ j ∧ j ≤ D.R.m then (((D.hc ρ).e ⟨j - 1, by omega⟩ : ℚ) : ℝ) else 0

def srcPar (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) (i : ℕ) : ℚ :=
  if h : i < D.R.k then (D.hcW u τ).u ⟨i, h⟩
  else
    if hb : (i - D.R.k) / (D.R.t + 1) < D.R.m then
      -(D.hcW u τ).e ⟨(i - D.R.k) / (D.R.t + 1), hb⟩ +
        ((D.R.t : ℚ) + 2 - 2 * (((i - D.R.k) % (D.R.t + 1) + 1 : ℕ) : ℚ)) / 2
    else 0

def nuRow (D : D7) (u : D.what₂.Word) (j : ℕ) (τ : D.what₂.Tau) (i : ℕ) : ℝ :=
  ((srcPar D u τ i : ℚ) : ℝ) + wSz D j τ -
    (((D.R.N (j - 1) : ℝ) + D.R.N j - 1 - 2 * (i : ℝ)) / 2)

end DV
namespace RowWeightLemmas
theorem cut_lt (R : Ranks) {i : ℕ} (hi : i < R.m) : R.N i < R.N R.m :=
  Nat.add_lt_add_left (Nat.mul_lt_mul_of_pos_right hi (Nat.succ_pos _)) _

def finalEntry (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) (r : ℕ) : ℤ :=
  if hr : r < D.R.N D.R.m then ((D.fm u).lam D.R.m τ).w ⟨r, hr⟩ else 0

theorem final_antitone (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {r s : ℕ}
    (hrs : r ≤ s) (hs : s < D.R.N D.R.m) : finalEntry D u τ s ≤ finalEntry D u τ r := by
  simp only [finalEntry, dif_pos hs, dif_pos (lt_of_le_of_lt hrs hs)]
  exact ((D.fm u).lam D.R.m τ).anti hrs

theorem final_cut (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {i : ℕ} (hi : i < D.R.m) :
    (finalEntry D u τ (D.R.N i) : ℚ) = -wG D.R ((D.hcW u τ).e ⟨i,hi⟩) (i+1) := by
  rw [finalEntry, dif_pos (cut_lt D.R hi), (D.fm u).lam_eq D.R.m le_rfl τ]
  have hk : ¬D.R.N i < D.R.k := Nat.not_lt.mpr (Nat.le_add_right _ _)
  have hq : (D.R.N i-D.R.k)/(D.R.t+1) = i := by simp [Ranks.N]
  simp only [dif_neg hk, hq]

theorem nuRow_final (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m)
    (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    DV.nuRow D u (i+1) τ r = ((finalEntry D u τ r - finalEntry D u τ (D.R.N i) : ℤ) : ℝ) := by
  have hRm := hr.trans (cut_lt D.R hi)
  have hsu := (D.fm u).lam_eq D.R.m le_rfl τ ⟨r,hRm⟩
  have hcut := final_cut D u τ hi
  have hw : DV.wSz D (i+1) τ = (((D.hcW u τ).e ⟨i,hi⟩ : ℚ) : ℝ) := by
    simp [DV.wSz, D.hcW_e, Nat.succ_le_of_lt hi]
  rw [Int.cast_sub, ← Rat.cast_intCast (finalEntry D u τ r), ← Rat.cast_intCast (finalEntry D u τ (D.R.N i)), hcut,
    finalEntry, dif_pos hRm, hsu, DV.nuRow, hw]
  simp only [Nat.add_sub_cancel]
  unfold DV.srcPar
  by_cases hk : r < D.R.k
  · simp only [dif_pos hk, hcToWeightQ, rhoVec, wG, Ranks.N]
    push_cast
    ring
  · have hb := D.R.blk_lt (j := D.R.m) le_rfl (⟨r,hRm⟩ : Fin (D.R.N D.R.m)) hk
    simp only [dif_neg hk, dif_pos hb, wG, Ranks.N]
    have hsplit : r = D.R.k + (D.R.t+1)*((r-D.R.k)/(D.R.t+1)) + (r-D.R.k)%(D.R.t+1) := by
      have := Nat.div_add_mod (r-D.R.k) (D.R.t+1)
      omega
    have hd := congrArg (fun n : ℕ => (n : ℝ)) hsplit
    push_cast at hd ⊢
    linear_combination hd

theorem cut_nonneg (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m)
    (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    0 ≤ finalEntry D u τ r - finalEntry D u τ (D.R.N i) :=
  sub_nonneg.mpr (final_antitone D u τ hr.le (cut_lt D.R hi))

theorem nuRow_final_anti (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m)
    (τ : D.what₂.Tau) (r r' : ℕ) (h : r' ≤ r) (hr : r < D.R.N i) :
    DV.nuRow D u (i+1) τ r ≤ DV.nuRow D u (i+1) τ r' := by
  rw [nuRow_final D u i hi τ r hr, nuRow_final D u i hi τ r' (h.trans_lt hr)]
  exact_mod_cast sub_le_sub_right (final_antitone D u τ h (hr.trans (cut_lt D.R hi))) _

end RowWeightLemmas
abbrev HH (D : D7) := D.what₂.Tau
def tauPl (D : D7) (z : Bool × HH D) : D.what₂.Tau := z.2
def nuD (D : D7) (u : D.what₂.Word) (i : ℕ) (z : Bool × HH D) : YoungDiagram where
  cells := ((Finset.range (D.R.N i)) ×ˢ (Finset.range ⌈DV.nuRow D u (i + 1) (tauPl D z) 0⌉₊)).filter
    fun x => ∀ r' ≤ x.1, (x.2 : ℝ) < DV.nuRow D u (i + 1) (tauPl D z) r'
  isLowerSet := by
    intro a b hba ha
    simp only [Finset.coe_filter, Finset.mem_product, Finset.mem_range, Set.mem_ofPred_eq] at ha ⊢
    obtain ⟨⟨h1, h2⟩, h3⟩ := ha
    have hb1 : b.1 ≤ a.1 := hba.1
    have hb2 : b.2 ≤ a.2 := hba.2
    refine ⟨⟨lt_of_le_of_lt hb1 h1, lt_of_le_of_lt hb2 h2⟩, fun r' hr' => ?_⟩
    exact lt_of_le_of_lt (by exact_mod_cast hb2) (h3 r' (le_trans hr' hb1))

def NuRowOK (D : D7) : Prop :=
  ∀ u i, i < D.R.m → ∀ z r, (((nuD D u i z).rowLen r : ℕ) : ℝ) =
    if r < D.R.N i then DV.nuRow D u (i + 1) (tauPl D z) r else 0

def nuAbs (D : D7) (u : D.what₂.Word) (j : ℕ) (τ : D.what₂.Tau) : ℝ :=
  ∑ i ∈ Finset.range (D.R.N (j - 1)), DV.nuRow D u j τ i

namespace RowWeightLemmas

theorem final_flat (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {i r : ℕ} (hi : i < D.R.m)
    (hr : D.R.N i ≤ r) (hr' : r < D.R.N (i+1)) :
    finalEntry D u τ r = finalEntry D u τ (D.R.N i) := by
  have hb : r < D.R.N D.R.m := hr'.trans_le (Nat.add_le_add_left (Nat.mul_le_mul_right _ hi) _)
  have hlo : D.R.k+i*(D.R.t+1) ≤ r := hr
  have hhi : r < D.R.k+(i+1)*(D.R.t+1) := hr'
  have q : (r-D.R.k)/(D.R.t+1) = i :=
    Nat.div_eq_of_lt_le (by omega) (by omega)
  have e := (D.fm u).lam_eq D.R.m le_rfl τ ⟨r,hb⟩
  have hcut := final_cut D u τ hi
  have hk : ¬r < D.R.k := by omega
  simp only [dif_neg hk,q] at e
  rw [finalEntry, dif_pos hb]
  exact_mod_cast e.trans hcut.symm

theorem nuAbs_prefix (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) :
    nuAbs D u (i+1) τ = (∑ r ∈ Finset.range (D.R.N i), (finalEntry D u τ r : ℝ)) -
      (D.R.N i : ℝ) * (finalEntry D u τ (D.R.N i) : ℝ) := by
  unfold nuAbs
  simp only [Nat.add_sub_cancel]
  calc (∑ r ∈ Finset.range (D.R.N i), DV.nuRow D u (i+1) τ r)
      = ∑ r ∈ Finset.range (D.R.N i), ((finalEntry D u τ r : ℝ) - finalEntry D u τ (D.R.N i)) := by
        refine Finset.sum_congr rfl fun r hr => ?_
        rw [nuRow_final D u i hi τ r (Finset.mem_range.mp hr), Int.cast_sub]
    _ = _ := by simp [Finset.sum_sub_distrib]

theorem nuAbs_rectangle (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i+1 < D.R.m) (τ : D.what₂.Tau) :
    nuAbs D u (i+2) τ - nuAbs D u (i+1) τ =
      (D.R.N (i+1) : ℝ) * ((finalEntry D u τ (D.R.N i) : ℝ) - finalEntry D u τ (D.R.N (i+1))) := by
  rw [nuAbs_prefix D u (i+1) hi τ, nuAbs_prefix D u i (by omega) τ]
  have hN : D.R.N (i+1) = D.R.N i + (D.R.t+1) := by simp [Ranks.N,Nat.succ_mul,Nat.add_assoc]
  have flat : ∀ s ∈ Finset.range (D.R.t+1), (finalEntry D u τ (D.R.N i+s) : ℝ) =
      (finalEntry D u τ (D.R.N i) : ℝ) := by
    intro s hs
    have := Finset.mem_range.mp hs
    rw [final_flat D u τ (i := i) (by omega) (by omega) (by omega)]
  rw [hN, Finset.sum_range_add, Finset.sum_congr rfl flat]
  simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul, Nat.cast_add]
  ring

end RowWeightLemmas
namespace RowWeightLemmas

theorem cut_step (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {i : ℕ} (hi : i+1 < D.R.m) :
    ((finalEntry D u τ (D.R.N i) : ℝ) - finalEntry D u τ (D.R.N (i+1))) =
      ((((D.hcW u τ).e ⟨i+1,hi⟩ - (D.hcW u τ).e ⟨i,by omega⟩ : ℚ) : ℝ)) - (D.R.t+1) := by
  rw [← Rat.cast_intCast (finalEntry D u τ (D.R.N i)), ← Rat.cast_intCast (finalEntry D u τ (D.R.N (i+1))),
      final_cut D u τ (by omega), final_cut D u τ hi]
  unfold wG
  push_cast
  ring

theorem nuAbs_closed (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) (H : ℝ)
    (he : ∀ i (hi : i+1 < D.R.m), (((D.hcW u τ).e ⟨i+1,hi⟩ - (D.hcW u τ).e ⟨i,by omega⟩ : ℚ) : ℝ) = H)
    (i : ℕ) (hi : i < D.R.m) :
    nuAbs D u (i+1) τ = nuAbs D u 1 τ +
      (H-(D.R.t+1)) * (i * D.R.k + (D.R.t+1)*(i:ℝ)*(i+1)/2) := by
  induction i with
  | zero => simp
  | succ i ih =>
    have h := nuAbs_rectangle D u i hi τ
    rw [cut_step D u τ hi, he i hi, ih (by omega)] at h
    unfold Ranks.N at h
    push_cast at h ⊢
    linarith only [h]

theorem sum_nuAbs_closed (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) (H : ℝ)
    (he : ∀ i (hi : i+1 < D.R.m), (((D.hcW u τ).e ⟨i+1,hi⟩ - (D.hcW u τ).e ⟨i,by omega⟩ : ℚ) : ℝ) = H)
    (n : ℕ) (hn : n ≤ D.R.m) :
    (∑ i ∈ Finset.range n, nuAbs D u (i+1) τ) = (n:ℝ) * nuAbs D u 1 τ +
      (H-(D.R.t+1)) * (D.R.k * (n:ℝ)*(n-1)/2 + (D.R.t+1)*(n:ℝ)*(n-1)*(n+1)/6) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, ih (by omega), nuAbs_closed D u τ H he n hn]
    push_cast
    ring

end RowWeightLemmas
namespace RowWeightLemmas

def AffineE (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) (b H : ℝ) : Prop :=
  ∀ i : Fin D.R.m, (((D.hcW u τ).e i : ℚ) : ℝ) = b + (i.val : ℝ)*H + H/2

theorem affine_step (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {b H : ℝ} (h : AffineE D u τ b H)
    (i : ℕ) (hi : i+1 < D.R.m) : (((D.hcW u τ).e ⟨i+1,hi⟩ - (D.hcW u τ).e ⟨i,by omega⟩ : ℚ) : ℝ) = H := by
  rw [Rat.cast_sub,h,h]
  push_cast
  ring

theorem affine_cut_difference (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {b H : ℝ} (h : AffineE D u τ b H)
    {q i : ℕ} (hq : q < D.R.m) (hi : i < D.R.m) :
    ((finalEntry D u τ (D.R.N q) : ℝ) - finalEntry D u τ (D.R.N i)) =
       ((i:ℝ) - q) * (H-(D.R.t+1)) := by
  rw [← Rat.cast_intCast (finalEntry D u τ (D.R.N q)), ← Rat.cast_intCast (finalEntry D u τ (D.R.N i)),
      final_cut D u τ hq, final_cut D u τ hi]
  unfold wG
  push_cast
  rw [h,h]
  ring

theorem affine_head (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {b H : ℝ} (h : AffineE D u τ b H)
    {i r : ℕ} (hi : i < D.R.m) (hr : r < D.R.k) :
    DV.nuRow D u (i+1) τ r = DV.nuRow D u 1 τ r + (i:ℝ)*(H-(D.R.t+1)) := by
  have hr0 : r < D.R.N 0 := by simpa [Ranks.N] using hr
  have hri : r < D.R.N i := hr.trans_le (Nat.le_add_right _ _)
  have h0 : 0 < D.R.m := by omega
  rw [nuRow_final D u i hi τ r hri, nuRow_final D u 0 h0 τ r hr0, Int.cast_sub, Int.cast_sub]
  have e := affine_cut_difference D u τ h h0 hi
  simp only [Nat.cast_zero, sub_zero] at e
  linarith only [e]

theorem affine_block (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {b H : ℝ} (h : AffineE D u τ b H)
    {q i r : ℕ} (hq : q < i) (hi : i < D.R.m) (hr : D.R.N q ≤ r) (hr' : r < D.R.N (q+1)) :
    DV.nuRow D u (i+1) τ r = ((i:ℝ)-q)*(H-(D.R.t+1)) := by
  have hri : r < D.R.N i := hr'.trans_le (Nat.add_le_add_left (Nat.mul_le_mul_right _ hq) _)
  rw [nuRow_final D u i hi τ r hri, final_flat D u τ (hq.trans hi) hr hr', Int.cast_sub]
  exact affine_cut_difference D u τ h (hq.trans hi) hi

end RowWeightLemmas

#print axioms RowWeightLemmas.affine_head
#print axioms RowWeightLemmas.affine_block

#print axioms RowWeightLemmas.sum_nuAbs_closed
namespace RowWeightLemmas

def cutWidth (D : D7) (u : D.what₂.Word) (i : ℕ) (τ : D.what₂.Tau) (r : ℕ) : ℕ :=
  (finalEntry D u τ r - finalEntry D u τ (D.R.N i)).toNat

theorem cutWidth_cast (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m)
    (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    (cutWidth D u i τ r : ℝ) = DV.nuRow D u (i+1) τ r := by
  rw [nuRow_final D u i hi τ r hr, cutWidth, ← Int.cast_natCast, Int.toNat_of_nonneg (cut_nonneg D u i hi τ r hr)]

theorem mem_final_iff (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (z : Bool × HH D) (r c : ℕ) :
    (r,c) ∈ nuD D u i z ↔ r < D.R.N i ∧ c < cutWidth D u i (tauPl D z) r := by
  change (r,c) ∈ (nuD D u i z).cells ↔ _
  simp only [nuD, Finset.mem_filter, Finset.mem_product, Finset.mem_range]
  constructor
  · rintro ⟨⟨hr,-⟩,h⟩
    refine ⟨hr,?_⟩
    have hc := h r le_rfl
    rw [← cutWidth_cast D u i hi _ _ hr] at hc
    exact_mod_cast hc
  · rintro ⟨hr,h⟩
    have hc : (c : ℝ) < cutWidth D u i (tauPl D z) r := by exact_mod_cast h
    rw [cutWidth_cast D u i hi _ _ hr] at hc
    have below (r' : ℕ) (hr' : r' ≤ r) := hc.trans_le (nuRow_final_anti D u i hi _ r r' hr' hr)
    exact ⟨⟨hr, Nat.lt_ceil.mpr (below 0 (Nat.zero_le _))⟩, below⟩

theorem rowLen_final (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (z : Bool × HH D) (r : ℕ) :
    (nuD D u i z).rowLen r = if r < D.R.N i then cutWidth D u i (tauPl D z) r else 0 := by
  apply eq_of_forall_lt_iff
  intro c
  rw [← YoungDiagram.mem_iff_lt_rowLen, mem_final_iff D u i hi]
  split_ifs <;> simp_all

theorem width_transport (D : D7) (u : D.what₂.Word) {i j : ℕ} (hij : i < j) (hj : j < D.R.m)
    (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    cutWidth D u j τ r = cutWidth D u i τ r + cutWidth D u j τ (D.R.N i) := by
  have hN : D.R.N i < D.R.N j := Nat.add_lt_add_left (Nat.mul_lt_mul_of_pos_right hij (Nat.succ_pos _)) _
  have h1 := cut_nonneg D u i (hij.trans hj) τ r hr
  have h2 := cut_nonneg D u j hj τ (D.R.N i) hN
  unfold cutWidth
  omega

theorem crop_iff (D : D7) (u : D.what₂.Word) {i j : ℕ} (hij : i < j) (hj : j < D.R.m)
    (z : Bool × HH D) (r c : ℕ) :
    (r,c) ∈ nuD D u i z ↔ r < D.R.N i ∧
      (r,c + cutWidth D u j (tauPl D z) (D.R.N i)) ∈ nuD D u j z := by
  rw [mem_final_iff D u i (hij.trans hj), mem_final_iff D u j hj]
  by_cases hr : r < D.R.N i
  · have hN : D.R.N i < D.R.N j := Nat.add_lt_add_left (Nat.mul_lt_mul_of_pos_right hij (Nat.succ_pos _)) _
    rw [width_transport D u hij hj _ r hr]
    simp [hr,hr.trans hN]
  · simp [hr]

end RowWeightLemmas

namespace RowWeightLemmas
#print axioms crop_iff
#print axioms rowLen_final
#print axioms nuRow_final
#print axioms nuRow_final_anti
end RowWeightLemmas
def nuT (D : D7) (u : D.what₂.Word) (i : ℕ) : D.what₂.Tau → Fin (D.R.N i) → ℕ := fun τ r => ⌊DV.nuRow D u (i + 1) τ r⌋₊
def NuTIs : Prop :=
  ∀ (D : D7) (u : D.what₂.Word) (i : ℕ), i < D.R.m → ∀ (τ : D.what₂.Tau) (r : Fin (D.R.N i)),
    ((nuT D u i τ r : ℕ) : ℝ) = DV.nuRow D u (i + 1) τ r ∧ 0 < nuT D u i τ r
namespace RowWeightLemmas
theorem nuRow_int (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    ∃ z : ℤ, DV.nuRow D u (i + 1) τ r = z := by
  exact ⟨_, nuRow_final D u i hi τ r hr⟩
theorem nuRow_anti (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r : ℕ) (hr : r + 1 < D.R.N i) :
    DV.nuRow D u (i + 1) τ (r + 1) ≤ DV.nuRow D u (i + 1) τ r := by
  exact nuRow_final_anti D u i hi τ (r+1) r (Nat.le_succ _) hr
theorem nuRow_anti' (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r r' : ℕ) (h : r' ≤ r)
    (hr : r < D.R.N i) : DV.nuRow D u (i + 1) τ r ≤ DV.nuRow D u (i + 1) τ r' := by
  exact nuRow_final_anti D u i hi τ r r' h hr
end RowWeightLemmas
namespace RowWeightLemmas
theorem nuRow_head (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.k) :
    DV.nuRow D u (i + 1) τ r = (((D.hcW u τ).u ⟨r, hr⟩ + (D.hcW u τ).e ⟨i, hi⟩ -
      (2 * (D.R.N i : ℚ) + D.R.t - 2 * r) / 2 : ℚ) : ℝ) := by
  have hw : 1 ≤ i + 1 ∧ i + 1 ≤ D.R.m := ⟨by omega, by omega⟩
  unfold DV.nuRow DV.srcPar DV.wSz
  rw [dif_pos hr, dif_pos hw, ← D.hcW_e u τ]
  simp only [Nat.add_sub_cancel, Ranks.N]
  push_cast
  ring

theorem nuRow_block (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (q s : ℕ) (hq : q < i)
    (hs : s < D.R.t + 1) :
    DV.nuRow D u (i + 1) τ (D.R.k + q * (D.R.t + 1) + s) = (((D.hcW u τ).e ⟨i, hi⟩ - (D.hcW u τ).e ⟨q, by omega⟩ -
      ((i : ℚ) - q) * ((D.R.t : ℚ) + 1) : ℚ) : ℝ) := by
  have hw : 1 ≤ i + 1 ∧ i + 1 ≤ D.R.m := ⟨by omega, by omega⟩
  have hk : ¬ D.R.k + q * (D.R.t + 1) + s < D.R.k := by omega
  have h1 : D.R.k + q * (D.R.t + 1) + s - D.R.k = s + (D.R.t + 1) * q := by
    rw [Nat.mul_comm]; omega
  have hdiv : (D.R.k + q * (D.R.t + 1) + s - D.R.k) / (D.R.t + 1) = q := by
    rw [h1, Nat.add_mul_div_left _ _ (by omega), Nat.div_eq_of_lt hs, Nat.zero_add]
  have hmod : (D.R.k + q * (D.R.t + 1) + s - D.R.k) % (D.R.t + 1) = s := by
    rw [h1, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hs]
  unfold DV.nuRow DV.srcPar DV.wSz
  rw [dif_neg hk, dif_pos hw, ← D.hcW_e u τ]
  simp only [hdiv, hmod, Nat.add_sub_cancel, Ranks.N]
  rw [dif_pos (by omega : q < D.R.m)]
  push_cast
  ring

theorem e_step {R : Ranks} (P : HCParam R) (q : ℕ) (h : q + 1 < R.m) :
    (R.t : ℚ) + 3 ≤ P.e ⟨q + 1, h⟩ - P.e ⟨q, by omega⟩ := by
  have h1 := P.gap_eb ⟨q, by omega⟩ h
  have h2 := P.gap_be ⟨q + 1, h⟩
  linarith

theorem nuRow_last_pos (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) :
    0 < DV.nuRow D u (i + 1) τ (D.R.N i - 1) := by
  have hkpos : 0 < D.R.k := by have := D.R.m_add_three_le_k; omega
  rcases Nat.eq_zero_or_pos i with h | h
  · subst h
    have hN : D.R.N 0 - 1 = D.R.k - 1 := by unfold Ranks.N; omega
    rw [hN, nuRow_head D u 0 hi τ (D.R.k - 1) (by omega)]
    have h1 := (D.hcW u τ).u_last_gt (by omega) (by omega)
    have h2 := (D.hcW u τ).gap_be ⟨0, by omega⟩
    have hrq : ((D.R.k - 1 : ℕ) : ℚ) = (D.R.k : ℚ) - 1 := by
      rw [Nat.cast_sub (by omega)]; simp
    have h3 : (0 : ℚ) < (D.hcW u τ).u ⟨D.R.k - 1, by omega⟩ + (D.hcW u τ).e ⟨0, hi⟩ -
        (2 * (D.R.N 0 : ℚ) + D.R.t - 2 * ((D.R.k - 1 : ℕ) : ℚ)) / 2 := by
      rw [hrq]
      unfold Ranks.N
      push_cast
      linarith
    exact_mod_cast h3
  · obtain ⟨q, rfl⟩ : ∃ q, i = q + 1 := ⟨i - 1, by omega⟩
    have hN : D.R.N (q + 1) - 1 = D.R.k + q * (D.R.t + 1) + D.R.t := by
      unfold Ranks.N; rw [Nat.add_mul]; omega
    rw [hN, nuRow_block D u (q + 1) hi τ q D.R.t (by omega) (by omega)]
    have h1 := e_step (D.hcW u τ) q hi
    have h3 : (0 : ℚ) < (D.hcW u τ).e ⟨q + 1, hi⟩ - (D.hcW u τ).e ⟨q, by omega⟩ -
        (((q + 1 : ℕ) : ℚ) - (q : ℚ)) * ((D.R.t : ℚ) + 1) := by
      push_cast
      linarith
    exact_mod_cast h3

theorem nuRow_pos (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    0 < DV.nuRow D u (i + 1) τ r :=
  lt_of_lt_of_le (nuRow_last_pos D u i hi τ) (nuRow_anti' D u i hi τ (D.R.N i - 1) r (by omega) (by omega))
end RowWeightLemmas
theorem nuRow_nat (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r : ℕ) (hr : r < D.R.N i) :
    ∃ n : ℕ, 1 ≤ n ∧ DV.nuRow D u (i + 1) τ r = n := by
  refine ⟨_, ?_, (RowWeightLemmas.cutWidth_cast D u i hi τ r hr).symm⟩
  have hp := RowWeightLemmas.nuRow_pos D u i hi τ r hr
  rw [← RowWeightLemmas.cutWidth_cast D u i hi τ r hr] at hp
  exact_mod_cast hp
theorem nu_t_identity : NuTIs := by
  intro D u i hi τ r
  obtain ⟨n, hn, hrow⟩ := nuRow_nat D u i hi τ r r.2
  simpa [nuT, hrow] using (show (n : ℝ) = n ∧ 0 < n from ⟨rfl, hn⟩)
theorem nuRowOK (D : D7) : NuRowOK D := by
  intro u i hi z r
  rw [RowWeightLemmas.rowLen_final D u i hi z r]
  by_cases hr : r < D.R.N i
  · rw [if_pos hr, if_pos hr, RowWeightLemmas.cutWidth_cast D u i hi _ r hr]
  · simp [hr]
theorem nuRow_anti_le (D : D7) (u : D.what₂.Word) (i : ℕ) (hi : i < D.R.m) (τ : D.what₂.Tau) (r s : ℕ) (hrs : r ≤ s) (hs : s < D.R.N i) :
    DV.nuRow D u (i + 1) τ s ≤ DV.nuRow D u (i + 1) τ r := by
  exact RowWeightLemmas.nuRow_final_anti D u i hi τ s r hrs hs
#print axioms nuRowOK
#print axioms nu_t_identity
namespace RowWeightLemmas

theorem affineE_of_raw (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) (b : ℤ) (H : ℕ)
    (he : ∀ j : Fin D.R.m, (D.hc τ).b j = (b : ℚ) + (j.val : ℚ)*(H : ℚ) ∧
       (D.hc τ).e j = (D.hc τ).b j + (H : ℚ)/2) : AffineE D u τ b H := by
  intro j
  rw [D.hcW_e, (he j).2, (he j).1]
  push_cast
  ring

theorem affine_gap (D : D7) (u : D.what₂.Word) (τ : D.what₂.Tau) {b H : ℝ} (h : AffineE D u τ b H) :
    2 ≤ H - (D.R.t+1) := by
  have hm := D.R.two_le_m
  have hj : 0+1 < D.R.m := by omega
  have step := affine_step D u τ h 0 hj
  have gap := e_step (D.hcW u τ) 0 hj
  have gap' : (D.R.t : ℝ) + 3 ≤ (((D.hcW u τ).e ⟨0+1,hj⟩ - (D.hcW u τ).e ⟨0,by omega⟩ : ℚ) : ℝ) := by exact_mod_cast gap
  linarith only [step, gap']

end RowWeightLemmas

end Formalism.BasicNotions

namespace Formalism.BasicNotions
theorem nuD_rows (D : D7) (u : D.what₂.Word) (i : ℕ) (z : Bool × HH D) : (nuD D u i z).colLen 0 ≤ D.R.N i := by
  by_contra hlt
  have hmem : (D.R.N i, 0) ∈ nuD D u i z := YoungDiagram.mem_iff_lt_colLen.2 (not_le.1 hlt)
  have : (D.R.N i, 0) ∈ (nuD D u i z).cells := hmem
  simp only [nuD, Finset.mem_filter, Finset.mem_product, Finset.mem_range, lt_irrefl, false_and] at this
end Formalism.BasicNotions
open Formalism.BasicNotions Classical
namespace GlobalTheory

theorem youngDiagram_card_eq_sum_rowLen_range (μ : YoungDiagram) (n : ℕ) (h : μ.colLen 0 ≤ n) :
    μ.card = ∑ r ∈ Finset.range n, μ.rowLen r := by
  have hmap : ∀ c ∈ μ.cells, c.1 ∈ Finset.range n := by
    intro c hc
    rw [Finset.mem_range]
    have h1 : (c.1, c.2) ∈ μ := hc
    have h2 : (c.1, 0) ∈ μ := μ.up_left_mem le_rfl (Nat.zero_le _) h1
    exact lt_of_lt_of_le (YoungDiagram.mem_iff_lt_colLen.1 h2) h
  unfold YoungDiagram.card
  rw [Finset.card_eq_sum_card_fiberwise (f := Prod.fst) (fun c hc => hmap c hc)]
  refine Finset.sum_congr rfl fun r _ => ?_
  rw [YoungDiagram.rowLen_eq_card]
  rfl

theorem nuD_card_eq_sum_nuRow : ∀ (D : D7), NuRowOK D → ∀ (u : D.what₂.Word), ∀ j < D.R.m, ∀ (z : Bool × HH D), (((nuD D u j z).card : ℕ) : ℝ) = ∑ r ∈ Finset.range (D.R.N j), DV.nuRow D u (j + 1) (tauPl D z) r := by
  intro D hD u j hj z
  rw [youngDiagram_card_eq_sum_rowLen_range _ _ (nuD_rows D u j z), Nat.cast_sum]
  refine Finset.sum_congr rfl fun r hr => ?_
  rw [hD u j hj z r, if_pos (Finset.mem_range.1 hr)]

end GlobalTheory

namespace GlobalTheory

open Formalism.BasicNotions Formalism.BasicNotions.RowWeightLemmas

theorem nuD_card_as_area (D : D7) (u : D.what₂.Word) (j : ℕ) (hj : j < D.R.m) (z : Bool × HH D) :
    (((nuD D u j z).card : ℕ) : ℝ) = nuAbs D u (j+1) (tauPl D z) := by
  simpa only [nuAbs, Nat.add_sub_cancel] using nuD_card_eq_sum_nuRow D (nuRowOK D) u j hj z

theorem sum_nuD_card_closed (D : D7) (u : D.what₂.Word) (z : Bool × HH D) {b H : ℝ}
    (h : AffineE D u (tauPl D z) b H) (n : ℕ) (hn : n ≤ D.R.m) :
    (∑ i ∈ Finset.range n, ((nuD D u i z).card : ℝ)) = (n : ℝ) * ((nuD D u 0 z).card : ℝ) +
      (H-(D.R.t+1)) * (D.R.k * (n:ℝ)*(n-1)/2 + (D.R.t+1)*(n:ℝ)*(n-1)*(n+1)/6) := by
  have hm := D.R.two_le_m
  rw [nuD_card_as_area D u 0 (by omega)]
  refine Eq.trans (Finset.sum_congr rfl fun j hj => nuD_card_as_area D u j ((Finset.mem_range.mp hj).trans_le hn) z) ?_
  exact sum_nuAbs_closed D u (tauPl D z) H (affine_step D u _ h) n hn

end GlobalTheory

#print axioms GlobalTheory.sum_nuD_card_closed
#print axioms Formalism.BasicNotions.RowWeightLemmas.affineE_of_raw
#print axioms Formalism.BasicNotions.RowWeightLemmas.affine_gap
