import ChenDerivativeRoots

namespace ChenEndpoint

/-- One witness per gap, choosing the interior whenever the endpoints differ. -/
inductive GapChain : ℝ → List ℝ → List ℝ → Prop
  | nil (a : ℝ) : GapChain a [] []
  | cons {a b c : ℝ} {rs cs : List ℝ}
      (h : (a = b ∧ c = a) ∨ (a < c ∧ c < b))
      (tail : GapChain b rs cs) : GapChain a (b :: rs) (c :: cs)

private theorem gap_bounds {a b c : ℝ}
    (h : (a = b ∧ c = a) ∨ (a < c ∧ c < b)) : a ≤ c ∧ c ≤ b := by
  rcases h with ⟨rfl, rfl⟩ | ⟨h₁, h₂⟩
  · exact ⟨le_rfl, le_rfl⟩
  · exact ⟨h₁.le, h₂.le⟩

theorem GapChain.absent_below {x a : ℝ} {rs cs : List ℝ}
    (h : GapChain a rs cs) (hx : x < a) :
    x ∉ a :: rs ∧ x ∉ cs := by
  induction h with
  | nil a => simp [ne_of_lt hx]
  | @cons a b c rs cs hg _ ih =>
      have hh := gap_bounds hg
      obtain ⟨hr, hc⟩ := ih (hx.trans_le (hh.1.trans hh.2))
      exact ⟨by simp [ne_of_lt hx, hr], by simp [ne_of_lt (hx.trans_le hh.1), hc]⟩

/-- Multiplicity estimate for a strictly chosen gap chain: an original root x
loses at least one occurrence; any other x occurs at most once. -/
theorem GapChain.count_bound {x a : ℝ} {rs cs : List ℝ}
    (h : GapChain a rs cs) :
    (x ∈ a :: rs → cs.count x + 1 ≤ (a :: rs).count x) ∧
    (x ∉ a :: rs → cs.count x ≤ 1) := by
  classical
  induction h with
  | nil a =>
      constructor
      · intro hx
        have he : x = a := by simpa using hx
        subst x
        simp
      · simp
  | @cons a b c rs cs hg htail ih =>
      obtain ⟨ih₁, ih₂⟩ := ih
      by_cases hcx : c = x
      · subst c
        rcases hg with ⟨hab, hxa⟩ | ⟨hax, hxb⟩
        · subst b
          subst x
          have hb := ih₁ (by simp)
          constructor
          · intro _
            simpa using Nat.add_le_add_right hb 1
          · simp
        · obtain ⟨hr, hc⟩ := htail.absent_below hxb
          simp [ne_of_gt hax, hr, List.count_eq_zero_of_not_mem hc]
      · have hcount : (c :: cs).count x = cs.count x := by simp [hcx]
        rw [hcount]
        by_cases hx : x ∈ b :: rs
        · constructor
          · intro _
            exact (ih₁ hx).trans List.count_le_count_cons
          · simp [hx]
        · constructor
          · intro hxr
            have hxa : x = a := (List.mem_cons.mp hxr).resolve_right hx
            subst x
            have hne : a ≠ b := fun e => hx (by simp [e])
            have hlt := lt_of_le_of_ne ((gap_bounds hg).1.trans (gap_bounds hg).2) hne
            have hc := (htail.absent_below hlt).2
            simp [List.count_eq_zero_of_not_mem hc]
          · intro _
            exact ih₂ hx

end ChenEndpoint

#print axioms ChenEndpoint.GapChain.count_bound

