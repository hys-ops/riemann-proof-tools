import ChenEndpointComparison

open Polynomial

namespace ChenEndpoint

/-- All real roots at or below x give nonnegative evaluation to a split
polynomial with nonnegative leading coefficient. -/
theorem eval_nonneg_right_of_roots {p : ℝ[X]} (hp : p.Splits)
    (hl : 0 ≤ p.leadingCoeff) {x : ℝ} (hr : ∀ a ∈ p.roots, a ≤ x) :
    0 ≤ p.eval x := by
  rw [hp.eval_eq_prod_roots]
  apply mul_nonneg hl (Multiset.prod_nonneg _)
  intro y hy
  obtain ⟨a, ha, rfl⟩ := Multiset.mem_map.mp hy
  exact sub_nonneg.mpr (hr a ha)

/-- Positive derivative to the right of every critical point forces the
strictly increasing final branch, even if b itself is critical. -/
theorem strictMonoOn_right_of_critical_roots {p : ℝ[X]} {b : ℝ}
    (hdeg : 0 < p.natDegree) (hl : 0 < p.leadingCoeff)
    (hs : p.derivative.Splits) (hr : ∀ a ∈ p.derivative.roots, a ≤ b) :
    StrictMonoOn p.eval (Set.Ici b) := by
  apply strictMonoOn_of_deriv_pos (convex_Ici b) p.continuousOn
  intro x hx
  rw [interior_Ici] at hx
  rw [p.deriv, hs.eval_eq_prod_roots, leadingCoeff_derivative]
  refine mul_pos (mul_pos hl (by exact_mod_cast hdeg)) (Multiset.prod_pos ?_)
  intro y hy
  obtain ⟨a, ha, rfl⟩ := Multiset.mem_map.mp hy
  exact sub_pos.mpr ((hr a ha).trans_lt hx)

theorem right_tail_between_levels {p : ℝ[X]} {b : ℝ}
    (hdeg : 0 < p.natDegree) (hl : 0 < p.leadingCoeff)
    (hs : p.derivative.Splits) (hr : ∀ a ∈ p.derivative.roots, a ≤ b)
    (hb : p.eval b = -1) (h1 : p.eval 1 = 1) :
    ∀ x ∈ Set.Ioo b 1, -1 < p.eval x ∧ p.eval x < 1 := by
  have hm := strictMonoOn_right_of_critical_roots hdeg hl hs hr
  intro x hx
  exact ⟨hb ▸ hm (le_refl b) hx.1.le hx.1,
    h1 ▸ hm hx.1.le (hx.1.trans hx.2).le hx.2⟩

/-- If 1 is one of the two level roots and bounds all roots above, the
positive-leading polynomial has value +1 there, not -1. -/
theorem right_endpoint_positive_level {p : ℝ[X]}
    (hs : (p - C 1).Splits) (hl : 0 ≤ (p - C 1).leadingCoeff)
    (hr : ∀ a ∈ (p - C 1).roots, a ≤ 1)
    (h1 : p.eval 1 = 1 ∨ p.eval 1 = -1) : p.eval 1 = 1 := by
  have h := eval_nonneg_right_of_roots hs hl hr
  simp only [eval_sub, eval_C] at h
  rcases h1 with h1 | h1
  · exact h1
  · linarith

end ChenEndpoint

#print axioms ChenEndpoint.right_tail_between_levels
#print axioms ChenEndpoint.right_endpoint_positive_level

