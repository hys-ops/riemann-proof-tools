import ChebyshevMonicFibers
import Mathlib.RingTheory.MvPolynomial.Symmetric.NewtonIdentities
import Mathlib.RingTheory.Polynomial.Vieta
import Mathlib.Data.Multiset.Fintype

open Polynomial
open scoped BigOperators Polynomial
namespace ChenEndpoint

noncomputable def powerSum (s : Multiset ℝ) (k : ℕ) : ℝ :=
  (s.map (fun x => x ^ k)).sum

private theorem powerSum_recurrence (s : Multiset ℝ) (k : ℕ) (hk : 0 < k) :
    powerSum s k = (-1) ^ (k + 1) * (k : ℝ) * s.esymm k -
      ∑ a ∈ Finset.antidiagonal k with a.1 ∈ Set.Ioo 0 k,
        (-1) ^ a.1 * s.esymm a.1 * powerSum s a.2 := by
  classical
  let ev : MvPolynomial s ℝ →ₐ[ℝ] ℝ :=
    MvPolynomial.aeval (fun x : s => (x : ℝ))
  have hpsum (j : ℕ) : ev (MvPolynomial.psum s ℝ j) = powerSum s j := by
    simp only [ev, MvPolynomial.psum, map_sum, map_pow, MvPolynomial.aeval_X, powerSum]
    change ((Finset.univ : Finset s).val.map (fun x : s => (x : ℝ) ^ j)).sum = _
    exact congrArg Multiset.sum (Multiset.map_univ s (fun x : ℝ => x ^ j))
  have hesymm (j : ℕ) : ev (MvPolynomial.esymm s ℝ j) = s.esymm j := by
    simp [ev, MvPolynomial.aeval_esymm_eq_multiset_esymm]
  have h := congrArg ev (MvPolynomial.psum_eq_mul_esymm_sub_sum s ℝ k hk)
  simpa only [hpsum, hesymm, map_sub, map_mul, map_pow, map_neg, map_one, map_natCast,
    map_sum] using h

theorem powerSum_eq_of_esymm_agree (s t : Multiset ℝ) {n : ℕ}
    (he : ∀ j, 0 < j → j < n → s.esymm j = t.esymm j)
    {k : ℕ} (hk : 0 < k) (hkn : k < n) : powerSum s k = powerSum t k := by
  classical
  induction k using Nat.strong_induction_on with
  | h k ih =>
    rw [powerSum_recurrence s k hk, powerSum_recurrence t k hk, he k hk hkn]
    congr 1
    apply Finset.sum_congr rfl
    intro a ha
    have hsum : a.1 + a.2 = k := Finset.mem_antidiagonal.mp (Finset.mem_filter.mp ha).1
    have hi : 0 < a.1 ∧ a.1 < k := (Finset.mem_filter.mp ha).2
    rw [he a.1 hi.1 (hi.2.trans hkn), ih a.2 (by omega) (by omega) (by omega)]

theorem monicFiber_powerSums_eq_of_splits {n : ℕ} (hn : 2 ≤ n)
    (hp : (monicFiber n 1).Splits) (hm : (monicFiber n (-1)).Splits)
    {k : ℕ} (hk : 0 < k) (hkn : k < n) :
    powerSum (monicFiber n 1).roots k = powerSum (monicFiber n (-1)).roots k := by
  obtain ⟨hmp, hmm, hdp, hdm, hc⟩ := monic_pair_agree_above_constant hn
  apply powerSum_eq_of_esymm_agree _ _ (n := n) _ hk hkn
  intro j hj hjn
  have hc' := hc (n-j) (by omega)
  rw [Polynomial.coeff_eq_esymm_roots_of_splits hp (by omega),
      Polynomial.coeff_eq_esymm_roots_of_splits hm (by omega), hmp.leadingCoeff,
      hmm.leadingCoeff, hdp, hdm, one_mul,
      show n-(n-j) = j by omega] at hc'
  exact mul_left_cancel₀ (pow_ne_zero _ (by norm_num : (-1 : ℝ) ≠ 0)) hc'

#print axioms monicFiber_powerSums_eq_of_splits
end ChenEndpoint

