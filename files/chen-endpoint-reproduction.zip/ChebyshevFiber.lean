import Mathlib.Analysis.SpecialFunctions.Trigonometric.Chebyshev.RootsExtrema
import Mathlib.Tactic.Linarith

open Polynomial Polynomial.Chebyshev

namespace ChenEndpoint

/-- The largest point of the negative level fiber of the normalized Chebyshev
construction. This locates the sharpness candidate; it does not yet prove
cardinality with multiplicity or equality of the two fibers' power sums. -/
theorem greatest_neg_fiber {n : ℕ} (hn : 2 ≤ n) :
    IsGreatest {x : ℝ | (T ℝ (n : ℤ)).eval (2*x - 1) = -1}
      (Real.cos (Real.pi / (2*(n : ℝ))) ^ 2) := by
  have hn0 : n ≠ 0 := by omega
  have hnR : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (show 0 < n by omega)
  have harg : 2 * (Real.pi / (2 * (n : ℝ))) = Real.pi / n := by ring
  have htrig : 2 * Real.cos (Real.pi / (2*(n : ℝ))) ^ 2 - 1 =
      Real.cos (Real.pi / n) := by
    rw [← harg, Real.cos_two_mul]
  refine ⟨?_, ?_⟩
  · change (T ℝ (n : ℤ)).eval _ = -1
    rw [htrig]
    exact (eval_T_real_eq_neg_one_iff hn0 _).2 ⟨1, by omega, by decide, by simp⟩
  · intro x hx
    change (T ℝ (n : ℤ)).eval (2*x-1) = -1 at hx
    obtain ⟨k, hk, hodd, hcos⟩ := (eval_T_real_eq_neg_one_iff hn0 _).1 hx
    have hk1 : (1 : ℝ) ≤ (k : ℝ) := by
      exact_mod_cast (show 1 ≤ k by obtain ⟨j,hj⟩ := hodd; omega)
    have hkn : (k : ℝ) ≤ (n : ℝ) := by exact_mod_cast hk
    have hleft : 0 ≤ Real.pi / (n : ℝ) := div_nonneg Real.pi_pos.le hnR.le
    have hright : (k : ℝ) * Real.pi / (n : ℝ) ≤ Real.pi := by
      apply (div_le_iff₀ hnR).2
      rw [mul_comm Real.pi]
      exact mul_le_mul_of_nonneg_right hkn Real.pi_pos.le
    have hord : Real.pi / (n : ℝ) ≤ (k : ℝ) * Real.pi / (n : ℝ) := by
      apply div_le_div_of_nonneg_right _ hnR.le
      simpa only [one_mul] using mul_le_mul_of_nonneg_right hk1 Real.pi_pos.le
    have hle := Real.cos_le_cos_of_nonneg_of_le_pi hleft hright hord
    rw [← hcos, ← htrig] at hle
    linarith
#print axioms greatest_neg_fiber
end ChenEndpoint
