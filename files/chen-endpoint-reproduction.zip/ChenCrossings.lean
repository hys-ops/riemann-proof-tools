import ChenCriticalAlternation

open Polynomial

namespace ChenEndpoint

theorem exists_strict_root_of_opposite_signs {p : ℝ[X]} {a b : ℝ}
    (hab : a < b) (h : p.eval a * p.eval b < 0) :
    ∃ x ∈ Set.Ioo a b, p.IsRoot x := by
  have hone (h₁ : p.eval a ≤ 0) (h₂ : 0 ≤ p.eval b) :
      ∃ x ∈ Set.Icc a b, p.eval x = 0 :=
    intermediate_value_Icc hab.le p.continuousOn ⟨h₁, h₂⟩
  have htwo (h₁ : p.eval b ≤ 0) (h₂ : 0 ≤ p.eval a) :
      ∃ x ∈ Set.Icc a b, p.eval x = 0 :=
    intermediate_value_Icc' hab.le p.continuousOn ⟨h₁, h₂⟩
  obtain ⟨x, hx, he⟩ : ∃ x ∈ Set.Icc a b, p.eval x = 0 := by
    rcases mul_neg_iff.mp h with ⟨h₁, h₂⟩ | ⟨h₁, h₂⟩
    · exact htwo h₂.le h₁.le
    · exact hone h₁.le h₂.le
  have hna : a ≠ x := by rintro rfl; simp [he] at h
  have hnb : x ≠ b := by rintro rfl; simp [he] at h
  exact ⟨x, ⟨lt_of_le_of_ne hx.1 hna, lt_of_le_of_ne hx.2 hnb⟩, he⟩

/-- Every strict sign change across consecutive ordered inputs forces a
distinct real root; the total number of changes is bounded by degree. -/
theorem nat_le_natDegree_of_strict_sign_changes {p : ℝ[X]} (hp : p ≠ 0)
    {n : ℕ} {r : Fin (n + 1) → ℝ} (hr : StrictMono r)
    (ha : ∀ i : Fin n, p.eval (r i.castSucc) * p.eval (r i.succ) < 0) :
    n ≤ p.natDegree := by
  classical
  have H (i : Fin n) := exists_strict_root_of_opposite_signs
    (hr (show i.castSucc < i.succ from i.val.lt_succ_self)) (ha i)
  choose x hx hroot using H
  let y : Fin n → p.roots.toFinset := fun i =>
    ⟨x i, Multiset.mem_toFinset.mpr ((mem_roots hp).mpr (hroot i))⟩
  have hinj : Function.Injective y := by
    suffices hm : StrictMono x by exact fun i j hij => hm.injective (congrArg Subtype.val hij)
    intro i j hij
    have h₁ : i.succ ≤ j.castSucc := Nat.succ_le_of_lt hij
    exact (hx i).2.trans_le (hr.monotone h₁) |>.trans (hx j).1
  have hcard := Fintype.card_le_of_injective y hinj
  simp only [Fintype.card_fin, Fintype.card_coe] at hcard
  exact hcard.trans (p.roots.toFinset_card_le.trans p.card_roots')

end ChenEndpoint

#print axioms ChenEndpoint.nat_le_natDegree_of_strict_sign_changes

