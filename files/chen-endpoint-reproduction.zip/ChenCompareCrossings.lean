import ChenCompareAmplitude

open Polynomial

namespace ChenEndpoint

/-- An ordered array with n+1 comparisons of alternating margin, followed
by the distinguished + and − endpoints, is impossible at degree ≤ n+1. -/
theorem comparison_alternation_impossible {n : ℕ} {p q : ℝ[X]}
    (hp : p.natDegree ≤ n + 1) (hq : q.natDegree ≤ n + 1)
    {r : Fin ((n + 2) + 1) → ℝ} (hr : StrictMono r)
    (hpCore : ∀ i, i.val ≤ n → 1 ≤ (-1 : ℝ) ^ (n + 3 - i.val) * p.eval (r i))
    (hqCore : ∀ i, i.val ≤ n → |q.eval (r i)| ≤ 1)
    (hpLeft : -1 < p.eval (r ⟨n+1, by omega⟩))
    (hpRight : p.eval (r ⟨n+2, by omega⟩) < 1)
    (hqLeft : q.eval (r ⟨n+1, by omega⟩) = -1)
    (hqRight : q.eval (r ⟨n+2, by omega⟩) = 1) : False := by
  obtain ⟨amp, ha₀, ha₁, hleft, hright⟩ := exists_comparison_amplitude hpLeft hpRight
  let f := p - C amp * q
  have hsign (i : Fin ((n + 2) + 1)) :
      0 < (-1 : ℝ) ^ (n + 3 - i.val) * f.eval (r i) := by
    by_cases hi : i.val ≤ n
    · simp only [f, eval_sub, eval_mul, eval_C]
      exact perturbation_preserves_margin ha₀.le ha₁ (neg_one_pow_eq_or ℝ _)
        (hpCore i hi) (hqCore i hi)
    · by_cases he : i.val = n + 1
      · have hidx : i = ⟨n+1, by omega⟩ := Fin.ext he
        have hpow : n+3 - i.val = 2 := by omega
        rw [hpow, hidx]
        norm_num [f, hqLeft]
        linarith
      · have he' : i.val = n+2 := by have := i.isLt; omega
        have hidx : i = ⟨n+2, by omega⟩ := Fin.ext he'
        have hpow : n+3 - i.val = 1 := by omega
        rw [hpow, hidx]
        norm_num [f, hqRight]
        linarith
  have hne : f ≠ 0 := by
    intro hz
    have h := hsign 0
    simp [hz] at h
  have hchanges (i : Fin (n+2)) : f.eval (r i.castSucc) * f.eval (r i.succ) < 0 := by
    have ha := hsign i.castSucc
    have hb := hsign i.succ
    have hpow : n+3 - i.castSucc.val = (n+3 - i.succ.val) + 1 := by
      change n+3 - i.val = (n+3 - (i.val+1)) + 1
      have := i.isLt
      omega
    rw [hpow, pow_succ] at ha
    rcases neg_one_pow_eq_or ℝ (n+3 - i.succ.val) with hs | hs
    · rw [hs] at ha hb
      norm_num at ha hb
      exact mul_neg_of_neg_of_pos (by linarith) hb
    · rw [hs] at ha hb
      norm_num at ha hb
      exact mul_neg_of_pos_of_neg ha (by linarith)
  have hlo := nat_le_natDegree_of_strict_sign_changes hne hr hchanges
  have hhi : f.natDegree ≤ n+1 := by
    refine (natDegree_sub_le p (C amp * q)).trans (max_le hp ?_)
    exact (natDegree_mul_le.trans (by simpa using hq))
  omega

end ChenEndpoint

#print axioms ChenEndpoint.comparison_alternation_impossible

