import ChebyshevFiber
import ChebyshevMonicFibers
import ChenCompareCrossings

open Polynomial Polynomial.Chebyshev

namespace ChenEndpoint

/-- Degree-n Chebyshev comparison on [0,v], with u=qv the last negative
extremum. The strict amplitude in the crossing argument permits the
left endpoint of the comparison interval to be exactly zero. -/
theorem exists_affine_chebyshev_comparator {n : ℕ} (hn : 2 ≤ n) {b : ℝ}
    (hb₀ : 0 ≤ b)
    (hb : b < Real.cos (Real.pi / (2 * (n : ℝ))) ^ 2) :
    ∃ u v : ℝ, ∃ Q : ℝ[X],
      b < u ∧ u < v ∧ v < 1 ∧ Q.natDegree = n ∧
      Q.eval u = -1 ∧ Q.eval v = 1 ∧ ∀ x ∈ Set.Icc 0 v, |Q.eval x| ≤ 1 := by
  let q := Real.cos (Real.pi / (2 * (n : ℝ))) ^ 2
  have hqpos : 0 < q := hb₀.trans_lt hb
  have hnR : (0 : ℝ) < (n : ℝ) := by exact_mod_cast (show 0 < n by omega)
  have hargpos : 0 < Real.pi / (2 * (n : ℝ)) := div_pos Real.pi_pos (by positivity)
  have harglt : Real.pi / (2 * (n : ℝ)) < Real.pi / 2 := by
    apply (div_lt_iff₀ (show 0 < 2 * (n : ℝ) by positivity)).mpr
    have hn2 : (2 : ℝ) ≤ (n : ℝ) := by exact_mod_cast hn
    nlinarith [mul_le_mul_of_nonneg_left hn2 Real.pi_pos.le, Real.pi_pos]
  have hq1 : q < 1 := by
    have hc₀ := Real.cos_pos_of_mem_Ioo ⟨by linarith [Real.pi_pos], harglt⟩
    have hc₁ : Real.cos (Real.pi / (2 * (n : ℝ))) < 1 := by
      rw [← Real.cos_zero]
      exact Real.cos_lt_cos_of_nonneg_of_le_pi le_rfl (by linarith [Real.pi_pos]) hargpos
    dsimp [q]
    nlinarith [mul_pos hc₀ (sub_pos.mpr hc₁)]
  let u := (q + b) / 2
  let v := u / q
  have hbu : b < u := by dsimp [u]; linarith
  have hu₀ : 0 < u := hb₀.trans_lt hbu
  have huq : u < q := by dsimp [u]; linarith
  have hv₀ : 0 < v := div_pos hu₀ hqpos
  have hv₁ : v < 1 := (div_lt_one hqpos).mpr huq
  have huv : u < v := by
    apply (lt_div_iff₀ hqpos).mpr
    nlinarith [mul_pos hu₀ (sub_pos.mpr hq1)]
  let Q := (normalizedT n).comp (C v⁻¹ * X)
  have heval (x : ℝ) : Q.eval x = (T ℝ (n : ℤ)).eval (2 * (x / v) - 1) := by
    simp [Q, normalizedT, eval_comp, div_eq_mul_inv, mul_comm v⁻¹ x]
  have hu_div : u / v = q := by
    dsimp [v]
    field_simp
  refine ⟨u, v, Q, hbu, huv, hv₁, ?_, ?_, ?_, ?_⟩
  · dsimp only [Q]
    rw [natDegree_comp, natDegree_normalizedT, natDegree_C_mul (inv_ne_zero hv₀.ne'),
      natDegree_X, mul_one]
  · rw [heval, hu_div]
    exact (greatest_neg_fiber hn).1
  · rw [heval, div_self hv₀.ne']
    norm_num
  · intro x hx
    rw [heval]
    have h₀ : 0 ≤ x / v := div_nonneg hx.1 hv₀.le
    have h₁ : x / v ≤ 1 := (div_le_one hv₀).mpr hx.2
    apply abs_eval_T_real_le_one
    exact abs_le.mpr ⟨by linarith, by linarith⟩

end ChenEndpoint

#print axioms ChenEndpoint.exists_affine_chebyshev_comparator

