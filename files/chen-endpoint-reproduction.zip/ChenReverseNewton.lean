import ChenNewton
import ChenNormalizedUpper

open Polynomial
open scoped BigOperators Polynomial

namespace ChenEndpoint

private theorem reverseNewton_recurrence (s : Multiset ℝ) (k : ℕ) (hk : 0 < k) :
    powerSum s k = (-1) ^ (k + 1) * (k : ℝ) * s.esymm k -
      ∑ a ∈ Finset.antidiagonal k with a.1 ∈ Set.Ioo 0 k,
        (-1) ^ a.1 * s.esymm a.1 * powerSum s a.2 := by
  classical
  let ev : MvPolynomial s ℝ →ₐ[ℝ] ℝ :=
    MvPolynomial.aeval (fun x : s => (x : ℝ))
  have hpsum (j : ℕ) : ev (MvPolynomial.psum s ℝ j) = powerSum s j := by
    simp only [ev, MvPolynomial.psum, map_sum, map_pow, MvPolynomial.aeval_X, powerSum]
    change ((Finset.univ : Finset s).val.map (fun x : s => (x : ℝ) ^ j)).sum = _
    exact congrArg Multiset.sum (Multiset.map_univ s (fun x : ℝ => x ^ j))
  have hesymm (j : ℕ) : ev (MvPolynomial.esymm s ℝ j) = s.esymm j := by
    simp [ev, MvPolynomial.aeval_esymm_eq_multiset_esymm]
  have h := congrArg ev (MvPolynomial.psum_eq_mul_esymm_sub_sum s ℝ k hk)
  simpa only [hpsum, hesymm, map_sub, map_mul, map_pow, map_neg, map_one, map_natCast,
    map_sum] using h

/-- The reverse direction of Newton's identities for a finite initial range.
Multiplicities are retained because the input is a multiset. -/
theorem esymm_eq_of_powerSums_agree (s t : Multiset ℝ) {n : ℕ}
    (hs : ∀ j, 0 < j → j < n → powerSum s j = powerSum t j)
    {k : ℕ} (hkn : k < n) : s.esymm k = t.esymm k := by
  classical
  induction k using Nat.strong_induction_on with
  | h k ih =>
    by_cases hk : k = 0
    · simp [hk, Multiset.esymm]
    · have hkp : 0 < k := Nat.pos_of_ne_zero hk
      have ht :
          (∑ a ∈ Finset.antidiagonal k with a.1 ∈ Set.Ioo 0 k,
            (-1) ^ a.1 * s.esymm a.1 * powerSum s a.2) =
          ∑ a ∈ Finset.antidiagonal k with a.1 ∈ Set.Ioo 0 k,
            (-1) ^ a.1 * t.esymm a.1 * powerSum t a.2 := by
        apply Finset.sum_congr rfl
        intro a ha
        have hsum : a.1 + a.2 = k := Finset.mem_antidiagonal.mp (Finset.mem_filter.mp ha).1
        have hi : 0 < a.1 ∧ a.1 < k := (Finset.mem_filter.mp ha).2
        rw [ih a.1 hi.2 (hi.2.trans hkn), hs a.2 (by omega) (by omega)]
      have he := hs k hkp hkn
      rw [reverseNewton_recurrence s k hkp, reverseNewton_recurrence t k hkp, ht] at he
      apply mul_left_cancel₀ (a := (-1 : ℝ)^(k+1) * (k : ℝ))
      · exact mul_ne_zero (pow_ne_zero _ (by norm_num))
          (by exact_mod_cast hk)
      · exact sub_left_injective he

/-- The monic real polynomial whose root multiset is exactly s. -/
noncomputable def rootProduct (s : Multiset ℝ) : ℝ[X] :=
  (s.map (fun x => X - C x)).prod

theorem rootProduct_natDegree (s : Multiset ℝ) :
    (rootProduct s).natDegree = s.card := natDegree_multiset_prod_X_sub_C_eq_card s

theorem rootProduct_roots (s : Multiset ℝ) : (rootProduct s).roots = s :=
  roots_multiset_prod_X_sub_C s

theorem rootProduct_splits (s : Multiset ℝ) : (rootProduct s).Splits :=
  splits_iff_card_roots.mpr (by rw [rootProduct_roots, rootProduct_natDegree])

theorem rootProduct_monic (s : Multiset ℝ) : (rootProduct s).Monic := by
  exact monic_multiset_prod_of_monic s _ (fun _ _ => monic_X_sub_C _)

theorem rootProduct_coeff_agree_above_constant (s t : Multiset ℝ) {n : ℕ}
    (hsc : s.card = n) (htc : t.card = n)
    (hs : ∀ j, 0 < j → j < n → powerSum s j = powerSum t j) :
    ∀ k, 0 < k → (rootProduct s).coeff k = (rootProduct t).coeff k := by
  intro k hk
  have hd₁ := (rootProduct_natDegree s).trans hsc
  have hd₂ := (rootProduct_natDegree t).trans htc
  by_cases hkn : k ≤ n
  · rw [coeff_eq_esymm_roots_of_splits (rootProduct_splits s) (by omega),
        coeff_eq_esymm_roots_of_splits (rootProduct_splits t) (by omega),
        (rootProduct_monic s).leadingCoeff, (rootProduct_monic t).leadingCoeff,
        hd₁, hd₂, rootProduct_roots, rootProduct_roots,
        esymm_eq_of_powerSums_agree s t hs (by omega : n-k < n)]
  · rw [coeff_eq_zero_of_natDegree_lt (by omega : (rootProduct s).natDegree < k),
        coeff_eq_zero_of_natDegree_lt (by omega : (rootProduct t).natDegree < k)]

theorem rootProduct_sub_eq_C_of_powerSums (s t : Multiset ℝ) {n : ℕ}
    (hsc : s.card = n) (htc : t.card = n)
    (hs : ∀ j, 0 < j → j < n → powerSum s j = powerSum t j) :
    rootProduct s - rootProduct t = C ((rootProduct s).coeff 0 - (rootProduct t).coeff 0) := by
  ext k
  by_cases hk : k = 0
  · simp [hk]
  · rw [coeff_sub, coeff_C, if_neg hk,
        rootProduct_coeff_agree_above_constant s t hsc htc hs k (Nat.pos_of_ne_zero hk), sub_self]

end ChenEndpoint

#print axioms ChenEndpoint.esymm_eq_of_powerSums_agree
#print axioms ChenEndpoint.rootProduct_sub_eq_C_of_powerSums

