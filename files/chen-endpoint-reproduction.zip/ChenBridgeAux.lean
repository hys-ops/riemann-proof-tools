import ChenRightTail

open Polynomial

namespace ChenEndpoint

theorem GapChain.upper {a b : ℝ} {rs cs : List ℝ} (h : GapChain a rs cs)
    (hrs : ∀ x ∈ rs, x ≤ b) : ∀ x ∈ cs, x ≤ b := by
  induction h with
  | nil => simp
  | @cons a r c rs cs hc ht ih =>
      have hcr : c ≤ r := by
        rcases hc with ⟨rfl, rfl⟩ | ⟨_, h⟩
        · rfl
        · exact h.le
      intro x hx
      rcases List.mem_cons.mp hx with rfl | hx
      · exact hcr.trans (hrs _ (by simp))
      · exact ih (fun y hy => hrs _ (List.mem_cons_of_mem _ hy)) _ hx

theorem list_neg_signed_prod_nonneg {rs : List ℝ} (h : ∀ x ∈ rs, 0 ≤ x) :
    0 ≤ (-1 : ℝ)^rs.length * (rs.map fun x => -x).prod := by
  induction rs with
  | nil => simp
  | cons r rs ih =>
      simp only [List.length_cons, List.map_cons, List.prod_cons, pow_succ]
      calc
        0 ≤ r * ((-1 : ℝ)^rs.length * (rs.map fun x => -x).prod) :=
          mul_nonneg (h _ (by simp)) (ih (fun x hx => h _ (List.mem_cons_of_mem _ hx)))
        _ = _ := by ring

theorem signed_eval_zero_nonneg {p : ℝ[X]} {rs : List ℝ}
    (hp : p.Splits) (hL : 0 ≤ p.leadingCoeff)
    (hr : (rs : Multiset ℝ) = p.roots) (h0 : ∀ x ∈ rs, 0 ≤ x) :
    0 ≤ (-1 : ℝ)^rs.length * p.eval 0 := by
  rw [hp.eval_eq_prod_roots, ← hr, Multiset.map_coe, Multiset.prod_coe, mul_left_comm]
  simp only [zero_sub]
  exact mul_nonneg hL (list_neg_signed_prod_nonneg h0)

/-- Strict order follows from ordering plus alternation with a nonzero margin. -/
theorem strictMono_of_mono_critical_alternation {p : ℝ[X]} {n : ℕ}
    {c : Fin n → ℝ} (hc : Monotone c)
    (h : ∀ i, 1 ≤ (-1 : ℝ)^(n-i.val) * p.eval (c i)) :
    StrictMono c := by
  cases n with
  | zero => exact fun i => i.elim0
  | succ n =>
      apply Fin.strictMono_iff_lt_succ.mpr
      intro i
      have hle := hc (show i.castSucc ≤ i.succ from i.val.le_succ)
      refine lt_of_le_of_ne hle ?_
      intro hEq
      have h₁ := h i.castSucc
      have h₂ := h i.succ
      have hpow : n+1 - i.castSucc.val = (n+1-i.succ.val)+1 := by
        change n+1-i.val = (n+1-(i.val+1))+1
        have := i.isLt
        omega
      rw [hpow, pow_succ, hEq] at h₁
      nlinarith

end ChenEndpoint

#print axioms ChenEndpoint.GapChain.upper
#print axioms ChenEndpoint.signed_eval_zero_nonneg
#print axioms ChenEndpoint.strictMono_of_mono_critical_alternation

