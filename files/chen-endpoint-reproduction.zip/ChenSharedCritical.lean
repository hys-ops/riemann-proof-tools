import ChenInterlace

open Polynomial

namespace ChenEndpoint

private theorem shared_gap_bounds {a b c : ℝ}
    (h : (a = b ∧ c = a) ∨ (a < c ∧ c < b)) : a ≤ c ∧ c ≤ b := by
  rcases h with ⟨rfl, rfl⟩ | ⟨h₁, h₂⟩
  · exact ⟨le_rfl, le_rfl⟩
  · exact ⟨h₁.le, h₂.le⟩

theorem GapChain.lower {a : ℝ} {rs cs : List ℝ} (h : GapChain a rs cs) :
    ∀ x ∈ cs, a ≤ x := by
  induction h with
  | nil => simp
  | @cons a b c rs cs hc _ ih =>
      obtain ⟨hac, hcb⟩ := shared_gap_bounds hc
      intro x hx
      rcases List.mem_cons.mp hx with rfl | hx
      · exact hac
      · exact hac.trans (hcb.trans (ih x hx))

theorem GapChain.pairwise {a : ℝ} {rs cs : List ℝ} (h : GapChain a rs cs) :
    cs.Pairwise (· ≤ ·) := by
  induction h with
  | nil => simp
  | @cons a b c rs cs hc htail ih =>
      exact List.pairwise_cons.mpr
        ⟨fun x hx => (shared_gap_bounds hc).2.trans (htail.lower x hx), ih⟩

/-- Two split real polynomials with the same derivative share one ordered
critical-point list, with every multiplicity retained. -/
theorem shared_derivative_interlaces {p q : ℝ[X]} {a b : ℝ} {rs ss : List ℝ}
    (hp : p.Splits) (hq : q.Splits)
    (hpn : 0 < p.natDegree) (hqn : 0 < q.natDegree)
    (hps : (a :: rs).Pairwise (· ≤ ·)) (hqs : (b :: ss).Pairwise (· ≤ ·))
    (hpr : ((a :: rs : List ℝ) : Multiset ℝ) = p.roots)
    (hqr : ((b :: ss : List ℝ) : Multiset ℝ) = q.roots)
    (hd : p.derivative = q.derivative) :
    ∃ cs : List ℝ, GapChain a rs cs ∧ GapChain b ss cs ∧
      (cs : Multiset ℝ) = p.derivative.roots := by
  obtain ⟨cs, hpc, hc⟩ := derivative_roots_interlace hp hpn hps hpr
  obtain ⟨ds, hqc, hd'⟩ := derivative_roots_interlace hq hqn hqs hqr
  have hh : (cs : Multiset ℝ) = (ds : Multiset ℝ) := by rw [hc, hd, hd']
  have he : cs = ds := (Multiset.coe_eq_coe.mp hh).eq_of_pairwise'
    hpc.pairwise hqc.pairwise
  exact ⟨cs, hpc, he ▸ hqc, hc⟩

end ChenEndpoint

#print axioms ChenEndpoint.shared_derivative_interlaces

