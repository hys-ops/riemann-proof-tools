#!/bin/bash
set -euo pipefail
: "${MATHLIB_DIR:?Set MATHLIB_DIR to pinned Mathlib workspace}"
cd -- "$(dirname -- "$0")"
test "$(git -C "$MATHLIB_DIR" rev-parse HEAD)" = 0df444a360eaa60ab8c11dca51a86af692955474
lean --version | grep -F 'version 4.33.1,'
export LEAN_PATH="${LEAN_PATH_OVERRIDE:-$(cd "$MATHLIB_DIR" && lake env printenv LEAN_PATH)}:$PWD"
mkdir -p logs
for f in ChebyshevFiber ChebyshevMonicFibers ChebyshevSplit ChenNewton ChenAttainment ChenAttainmentSpan ChenDerivativeRoots ChenGapChain ChenInterlace ChenSharedCritical ChenGapSign ChenCriticalAlternation ChenCrossings ChenCompareAmplitude ChenCompareCrossings ChenAffineChebyshev ChenEndpointComparison ChenRightTail ChenBridgeAux ChenNormalizedUpper ChenReverseNewton ChenGeneralUpper; do
  lean -DwarningAsError=true -o "$f.olean" "$f.lean" > "logs/$f.log" 2>&1 || { cat "logs/$f.log"; exit 1; }
  printf 'PASS %s\n' "$f"
done
