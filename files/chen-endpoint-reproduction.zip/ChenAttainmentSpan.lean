import ChenAttainment

open Polynomial Polynomial.Chebyshev
open scoped Polynomial

namespace ChenEndpoint

theorem monicFiber_roots_mem_Icc {n : ℕ} (hn : 0 < n) {a x : ℝ}
    (ha : a = 1 ∨ a = -1) (hx : x ∈ (monicFiber n a).roots) : x ∈ Set.Icc (0 : ℝ) 1 := by
  have he := (mem_roots_monicFiber_iff hn a x).mp hx
  have hbound : |(T ℝ (n : ℤ)).eval (2*x-1)| ≤ 1 := by
    rw [he]
    rcases ha with rfl | rfl <;> norm_num
  have hi := (abs_eval_T_real_le_one_iff (show (n : ℤ) ≠ 0 by exact_mod_cast Nat.ne_of_gt hn) _).mpr hbound
  rw [abs_le] at hi
  exact ⟨by linarith [hi.1], by linarith [hi.2]⟩

theorem zero_mem_either_monicFiber {n : ℕ} (hn : 0 < n) :
    (0 : ℝ) ∈ (monicFiber n 1).roots ∨ (0 : ℝ) ∈ (monicFiber n (-1)).roots := by
  rw [mem_roots_monicFiber_iff hn, mem_roots_monicFiber_iff hn]
  have he : (T ℝ (n : ℤ)).eval (2*0-1) = (-1 : ℝ)^n := by
    rw [show (2*0-1 : ℝ) = -1 by norm_num, ← Real.cos_pi, T_real_cos]
    simpa using Real.cos_nat_mul_pi n
  rw [he]
  exact neg_one_pow_eq_or ℝ n

theorem normalized_span_of_monicFibers {n : ℕ} (hn : 2 ≤ n) :
    IsLeast {x : ℝ | x ∈ (monicFiber n 1).roots ∨ x ∈ (monicFiber n (-1)).roots} 0 ∧
    IsGreatest {x : ℝ | x ∈ (monicFiber n 1).roots ∨ x ∈ (monicFiber n (-1)).roots} 1 := by
  have hnp : 0 < n := by omega
  have hbound {x : ℝ} (hx : x ∈ (monicFiber n 1).roots ∨ x ∈ (monicFiber n (-1)).roots) :
      x ∈ Set.Icc (0 : ℝ) 1 := by
    rcases hx with hp | hm
    · exact monicFiber_roots_mem_Icc hnp (Or.inl rfl) hp
    · exact monicFiber_roots_mem_Icc hnp (Or.inr rfl) hm
  have hp : (1 : ℝ) ∈ (monicFiber n 1).roots :=
    (mem_roots_monicFiber_iff hnp 1 1).mpr (greatest_pos_fiber hn).1
  exact ⟨⟨zero_mem_either_monicFiber hnp, fun _ hx => (hbound hx).1⟩,
    ⟨Or.inl hp, fun _ hx => (hbound hx).2⟩⟩

/-- Attainment with the exact trigonometric gap and the full normalized span
certified. The general upper bound is a separate problem. -/
theorem chebyshev_attainment_normalized {n : ℕ} (hn : 2 ≤ n) :
    let p := monicFiber n 1
    let m := monicFiber n (-1)
    let angle := Real.pi / (2*(n : ℝ))
    p.roots.card = n ∧ m.roots.card = n ∧
    (∀ k, 0 < k → k < n → powerSum p.roots k = powerSum m.roots k) ∧
    IsLeast {x : ℝ | x ∈ p.roots ∨ x ∈ m.roots} 0 ∧
    IsGreatest {x : ℝ | x ∈ p.roots ∨ x ∈ m.roots} 1 ∧
    IsGreatest {x : ℝ | x ∈ p.roots} 1 ∧
    IsGreatest {x : ℝ | x ∈ m.roots} (Real.cos angle ^ 2) ∧
    1 - Real.cos angle ^ 2 = Real.sin angle ^ 2 := by
  dsimp only
  obtain ⟨hc₁, hc₂, hsum, hp, hm⟩ := chebyshev_attainment hn
  obtain ⟨hlo, hhi⟩ := normalized_span_of_monicFibers hn
  refine ⟨hc₁, hc₂, hsum, hlo, hhi, hp, hm, ?_⟩
  linarith [Real.sin_sq_add_cos_sq (Real.pi / (2*(n : ℝ)))]

#print axioms chebyshev_attainment_normalized
end ChenEndpoint

