import ChenReverseNewton

open Polynomial

namespace ChenEndpoint

private theorem eval_rootProduct_pos {s : Multiset ℝ} {a : ℝ} (h : ∀ x ∈ s, x < a) :
    0 < (rootProduct s).eval a := by
  rw [(rootProduct_splits s).eval_eq_prod_roots_of_monic (rootProduct_monic s), rootProduct_roots]
  apply Multiset.prod_pos
  intro x hx
  obtain ⟨y, hy, rfl⟩ := Multiset.mem_map.mp hx
  exact sub_pos.mpr (h y hy)

private theorem eval_rootProduct_eq_zero_iff (s : Multiset ℝ) (x : ℝ) :
    (rootProduct s).eval x = 0 ↔ x ∈ s := by
  have he : x ∈ (rootProduct s).roots ↔ (rootProduct s).IsRoot x :=
    mem_roots (rootProduct_monic s).ne_zero
  simpa only [rootProduct_roots, Polynomial.IsRoot] using he.symm

/-- Ordered, unequal maxima case of the original sharp multiset upper bound. -/
theorem ordered_strict_multiset_endpoint_upper {n : ℕ} (hn : 2 ≤ n)
    {A B : Multiset ℝ} (hA : A.card = n) (hB : B.card = n)
    (hs : ∀ k, 0 < k → k < n → powerSum A k = powerSum B k)
    {m a b : ℝ} (hm : IsLeast {x : ℝ | x ∈ A ∨ x ∈ B} m)
    (ha : IsGreatest {x : ℝ | x ∈ A} a) (hb : IsGreatest {x : ℝ | x ∈ B} b)
    (hab : b < a) :
    a-b ≤ (a-m) * Real.sin (Real.pi / (2*(n : ℝ))) ^ 2 := by
  let U := rootProduct A
  let V := rootProduct B
  have hUa : U.eval a = 0 := (eval_rootProduct_eq_zero_iff A a).mpr ha.1
  have hVa : 0 < V.eval a := eval_rootProduct_pos (fun x hx => (hb.2 hx).trans_lt hab)
  let D := V.eval a
  have hD : 0 < D := hVa
  have hconst : V - U = C D := by
    have h := rootProduct_sub_eq_C_of_powerSums B A hB hA (fun k hk hkn => (hs k hk hkn).symm)
    change V - U = C (V.coeff 0 - U.coeff 0) at h
    have he := congrArg (eval a) h
    simp only [eval_sub, eval_C, hUa, sub_zero] at he
    rw [← he] at h
    exact h
  have hVU : V = U + C D := by
    rw [← hconst]
    abel
  let l := a-m
  have hmb : m ≤ b := hm.2 (Or.inr hb.1)
  have hl : 0 < l := sub_pos.mpr (hmb.trans_lt hab)
  let L : ℝ[X] := C l * X + C m
  have hLd : L.natDegree = 1 := by
    rw [show L = C l * X + C m from rfl, natDegree_add_C, natDegree_C_mul hl.ne', natDegree_X]
  have hLe (x : ℝ) : L.eval x = l*x+m := by simp [L]
  have hLC : L.leadingCoeff = l := by
    rw [show L = C l * X + C m from rfl, leadingCoeff, hLd]
    simp
  let K := 2/D
  have hK : 0 < K := div_pos (by norm_num) hD
  let P : ℝ[X] := C K * U.comp L + C 1
  have hPminus : P - C 1 = C K * U.comp L := by simp [P]
  have hPplus : P + C 1 = C K * V.comp L := by
    rw [hVU, add_comp, C_comp, mul_add, ← C_mul]
    have hkd : K*D = 2 := div_mul_cancel₀ _ hD.ne'
    rw [hkd, show P = C K * U.comp L + C 1 from rfl]
    rw [add_assoc, ← map_add]
    norm_num
  have hUd : U.natDegree = n := (rootProduct_natDegree A).trans hA
  have hVd : V.natDegree = n := (rootProduct_natDegree B).trans hB
  have hPd : P.natDegree = n := by
    rw [show P = C K * U.comp L + C 1 from rfl, natDegree_add_C,
      natDegree_C_mul hK.ne', natDegree_comp, hUd, hLd, mul_one]
  have hPlc : 0 < P.leadingCoeff := by
    have h0 : (C (1 : ℝ)).degree < (C K * U.comp L).degree := by
      apply degree_C_le.trans_lt
      have hc : (C K * U.comp L).natDegree = n := by
        rw [natDegree_C_mul hK.ne', natDegree_comp, hUd, hLd, mul_one]
      rw [degree_eq_natDegree (ne_zero_of_natDegree_gt (by omega : 0 < (C K * U.comp L).natDegree)), hc]
      exact WithBot.coe_lt_coe.mpr (by omega : 0 < n)
    rw [show P = C K * U.comp L + C 1 from rfl, leadingCoeff_add_of_degree_lt' h0,
      leadingCoeff_mul, leadingCoeff_C, leadingCoeff_comp, hLC, hUd,
      (rootProduct_monic A).leadingCoeff, one_mul]
    · positivity
    · rw [hLd]; decide
  have hplus : (P+C 1).Splits := by
    rw [hPplus]
    exact (Splits.C _).mul ((rootProduct_splits B).comp_of_natDegree_le_one hLd.le)
  have hminus : (P-C 1).Splits := by
    rw [hPminus]
    exact (Splits.C _).mul ((rootProduct_splits A).comp_of_natDegree_le_one hLd.le)
  have htroot (s : Multiset ℝ) (x : ℝ) :
      x ∈ (C K * (rootProduct s).comp L).roots ↔ l*x+m ∈ s := by
    have hpZ : C K * (rootProduct s).comp L ≠ 0 := by
      apply mul_ne_zero (C_ne_zero.mpr hK.ne')
      intro hh
      have h1 := congrArg natDegree hh
      rw [natDegree_comp, hLd, mul_one, rootProduct_natDegree, natDegree_zero] at h1
      have hconst : rootProduct s = 1 := by
        have hz : s = 0 := Multiset.card_eq_zero.mp h1
        simp [rootProduct, hz]
      simp [hconst] at hh
    rw [mem_roots hpZ, IsRoot, eval_mul, eval_C, eval_comp, hLe,
      mul_eq_zero, or_iff_right hK.ne', eval_rootProduct_eq_zero_iff]
  have hboundA : ∀ x ∈ (P - C 1).roots, x ∈ Set.Icc 0 1 := by
    intro x hx
    rw [hPminus] at hx
    have h := (htroot A x).mp hx
    have hlo := hm.2 (Or.inl h)
    have hhi := ha.2 h
    change m ≤ l*x+m at hlo
    change l*x+m ≤ a at hhi
    have hlx : l*x ≤ l := by dsimp [l] at *; linarith
    exact ⟨nonneg_of_mul_nonneg_right (by linarith) hl,
      (mul_le_mul_iff_right₀ hl).mp (by simpa [mul_comm] using hlx)⟩
  let b' := (b-m)/l
  have hboundB : ∀ x ∈ (P+C 1).roots, x ∈ Set.Icc 0 b' := by
    intro x hx
    rw [hPplus] at hx
    have h := (htroot B x).mp hx
    have hlo := hm.2 (Or.inr h)
    have hhi := hb.2 h
    change m ≤ l*x+m at hlo
    change l*x+m ≤ b at hhi
    exact ⟨nonneg_of_mul_nonneg_right (by linarith) hl,
      (le_div_iff₀ hl).mpr (by linarith [mul_comm l x])⟩
  have h1 : P.eval 1 = 1 := by
    have h := (htroot A 1).mpr (by simpa [l] using ha.1)
    rw [← hPminus] at h
    have hz : (P-C 1).eval 1 = 0 := isRoot_of_mem_roots h
    simp only [eval_sub, eval_C] at hz
    linarith
  have hb' : P.eval b' = -1 := by
    have h := (htroot B b').mpr (by
      have he : l*b'+m = b := by dsimp [b']; field_simp; ring
      rw [he]
      exact hb.1)
    rw [← hPplus] at h
    have hz : (P+C 1).eval b' = 0 := isRoot_of_mem_roots h
    simp only [eval_add, eval_C] at hz
    linarith
  have hN : n-1+1 = n := by omega
  have hc := normalized_split_levels_endpoint_bound (n := n-1) (by omega)
    (hPd.trans hN.symm) hPlc hminus hplus (div_nonneg (sub_nonneg.mpr hmb) hl.le)
    hboundA hboundB hb' (Or.inl h1)
  rw [hN] at hc
  have hmul := (le_div_iff₀ hl).mp hc
  have hid := Real.sin_sq_add_cos_sq (Real.pi / (2*(n : ℝ)))
  dsimp [l] at hmul
  nlinarith [congrArg (fun x : ℝ => (a-m)*x) hid]

/-- Sharp endpoint upper bound for two equally large real multisets with
equal power sums of degrees 1 through n-1, in their original units. -/
theorem multiset_endpoint_upper {n : ℕ} (hn : 2 ≤ n)
    {A B : Multiset ℝ} (hA : A.card = n) (hB : B.card = n)
    (hs : ∀ k, 0 < k → k < n → powerSum A k = powerSum B k)
    {m a b : ℝ} (hm : IsLeast {x : ℝ | x ∈ A ∨ x ∈ B} m)
    (ha : IsGreatest {x : ℝ | x ∈ A} a) (hb : IsGreatest {x : ℝ | x ∈ B} b) :
    |a-b| ≤ (max a b-m) * Real.sin (Real.pi / (2*(n : ℝ))) ^ 2 := by
  obtain h | rfl | h := lt_trichotomy b a
  · rw [abs_of_nonneg (sub_nonneg.mpr h.le), max_eq_left h.le]
    exact ordered_strict_multiset_endpoint_upper hn hA hB hs hm ha hb h
  · have hh : m ≤ b := hm.2 (Or.inr hb.1)
    simpa [sub_self] using mul_nonneg (sub_nonneg.mpr hh)
      (sq_nonneg (Real.sin (Real.pi / (2*(n : ℝ)))))
  · rw [abs_of_nonpos (sub_nonpos.mpr h.le), max_eq_right h.le, neg_sub]
    have hm' : IsLeast {x : ℝ | x ∈ B ∨ x ∈ A} m := by simpa only [or_comm] using hm
    exact ordered_strict_multiset_endpoint_upper hn hB hA (fun k hk hkn => (hs k hk hkn).symm) hm' hb ha h

end ChenEndpoint

#print axioms ChenEndpoint.multiset_endpoint_upper

