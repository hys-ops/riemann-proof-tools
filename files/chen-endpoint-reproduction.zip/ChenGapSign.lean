import ChenSharedCritical

open Polynomial

namespace ChenEndpoint

private theorem right_factor_sign {x : ℝ} {rs : List ℝ} (h : ∀ y ∈ rs, x ≤ y) :
    0 ≤ (-1 : ℝ)^rs.length * (rs.map fun y => x - y).prod := by
  induction rs with
  | nil => simp
  | cons y ys ih =>
      have hxy := h y (by simp)
      have hii := ih (fun z hz => h z (List.mem_cons_of_mem _ hz))
      simp only [List.length_cons, List.map_cons, List.prod_cons, pow_succ]
      calc
        0 ≤ (y - x) * ((-1 : ℝ)^ys.length * (ys.map fun z => x - z).prod) :=
          mul_nonneg (sub_nonneg.mpr hxy) hii
        _ = _ := by ring

private theorem gap_endpoints {a b c : ℝ}
    (h : (a = b ∧ c = a) ∨ (a < c ∧ c < b)) : a ≤ c ∧ c ≤ b := by
  rcases h with ⟨rfl, rfl⟩ | ⟨h₁, h₂⟩
  · exact ⟨le_rfl, le_rfl⟩
  · exact ⟨h₁.le, h₂.le⟩

/-- Sign of the split root product evaluated at the ith interlacing point. -/
theorem GapChain.signed_product_nonneg {a : ℝ} {rs cs : List ℝ}
    (h : GapChain a rs cs) (hs : (a :: rs).Pairwise (· ≤ ·))
    (i : ℕ) (hi : i < cs.length) :
    0 ≤ (-1 : ℝ) ^ (rs.length - i) * ((a :: rs).map fun y => cs[i] - y).prod := by
  induction h generalizing i with
  | nil a => simp at hi
  | @cons a b c rs cs hc ht ih =>
      have hends := gap_endpoints hc
      have hs' := (List.pairwise_cons.mp hs).2
      cases i with
      | zero =>
          simp only [Nat.sub_zero, List.getElem_cons_zero, List.map_cons, List.prod_cons]
          have hright : 0 ≤ (-1 : ℝ) ^ (b :: rs).length *
              ((b :: rs).map fun y => c - y).prod := by
            apply right_factor_sign
            intro y hy
            obtain rfl | hy := List.mem_cons.mp hy
            · exact hends.2
            · exact hends.2.trans ((List.pairwise_cons.mp hs').1 _ hy)
          change 0 ≤ (-1 : ℝ) ^ (b :: rs).length * ((c - a) * ((b :: rs).map fun y => c - y).prod)
          rw [mul_left_comm]
          exact mul_nonneg (sub_nonneg.mpr hends.1) hright
      | succ i =>
          have hi' : i < cs.length := by simpa using hi
          have hh := ih hs' i hi'
          have hxa : a ≤ cs[i] := hends.1.trans (hends.2.trans (ht.lower _ (List.getElem_mem hi')))
          simp only [List.getElem_cons_succ, List.length_cons, Nat.add_sub_add_right,
            List.map_cons, List.prod_cons]
          change 0 ≤ (-1 : ℝ) ^ (rs.length - i) * ((cs[i] - a) * ((b :: rs).map fun y => cs[i] - y).prod)
          rw [mul_left_comm]
          exact mul_nonneg (sub_nonneg.mpr hxa) hh

end ChenEndpoint

#print axioms ChenEndpoint.GapChain.signed_product_nonneg

