import ChenGapChain

open Polynomial

namespace ChenEndpoint

theorem GapChain.length_eq {a : ℝ} {rs cs : List ℝ} (h : GapChain a rs cs) :
    cs.length = rs.length := by
  induction h with
  | nil => rfl
  | cons _ _ ih => simp [ih]

private theorem build_gap_chain {p : ℝ[X]} {a : ℝ} {rs : List ℝ}
    (hs : (a :: rs).Pairwise (· ≤ ·)) (hr : ∀ x ∈ a :: rs, p.IsRoot x)
    (hm : ∀ x : ℝ, 1 < (a :: rs).count x → 1 < p.rootMultiplicity x)
    (hp : p ≠ 0) :
    ∃ cs, GapChain a rs cs ∧ ∀ x ∈ cs, p.derivative.IsRoot x := by
  classical
  induction rs generalizing a with
  | nil => exact ⟨[], GapChain.nil _, by simp⟩
  | cons b rs ih =>
      have htail := (List.pairwise_cons.mp hs).2
      have hab := (List.pairwise_cons.mp hs).1 b (by simp)
      obtain ⟨cs, hc, hcr⟩ := ih htail (fun x hx => hr x (List.mem_cons_of_mem _ hx))
        (fun x hx => hm x (hx.trans_le List.count_le_count_cons))
      obtain ⟨c, hgap, hderiv⟩ :
          ∃ c, ((a = b ∧ c = a) ∨ (a < c ∧ c < b)) ∧ p.derivative.IsRoot c := by
        obtain hlt | heq := lt_or_eq_of_le hab
        · have ha := hr a (by simp)
          have hb := hr b (by simp)
          obtain ⟨c, hci, hz⟩ := exists_deriv_eq_zero hlt p.continuousOn (ha.trans hb.symm)
          exact ⟨c, Or.inr hci, by simpa only [Polynomial.IsRoot, ← p.deriv] using hz⟩
        · refine ⟨a, Or.inl ⟨heq, rfl⟩, ((one_lt_rootMultiplicity_iff_isRoot hp).mp (hm a ?_)).2⟩
          subst b
          simp
      refine ⟨c :: cs, GapChain.cons hgap hc, ?_⟩
      intro x hx
      rcases List.mem_cons.mp hx with he | ht
      · simpa only [he] using hderiv
      · exact hcr x ht

/-- Ordered derivative-root interlacing, with every multiplicity retained. A
`GapChain` places one derivative root into each adjacent gap of the sorted
root list, so the output is automatically nondecreasing. -/
theorem derivative_roots_interlace {p : ℝ[X]} {a : ℝ} {rs : List ℝ}
    (hp : p.Splits) (hpos : 0 < p.natDegree)
    (hs : (a :: rs).Pairwise (· ≤ ·))
    (hr : ((a :: rs : List ℝ) : Multiset ℝ) = p.roots) :
    ∃ cs : List ℝ, GapChain a rs cs ∧ (cs : Multiset ℝ) = p.derivative.roots := by
  classical
  have hpd : p.derivative ≠ 0 := derivative_ne_zero.mpr (ne_of_gt hpos)
  have hp₀ : p ≠ 0 := ne_of_apply_ne derivative (by simpa only [derivative_zero] using hpd)
  have hmem : ∀ x ∈ a :: rs, p.IsRoot x := by
    intro x hx
    apply (mem_roots hp₀).mp
    simpa only [← hr, Multiset.mem_coe] using hx
  have hmult : ∀ x : ℝ, (a :: rs).count x = p.rootMultiplicity x := by
    intro x
    rw [← count_roots, ← hr, Multiset.coe_count]
  obtain ⟨cs, hc, hderiv⟩ := build_gap_chain hs hmem (fun x h => (hmult x) ▸ h) hp₀
  refine ⟨cs, hc, Multiset.eq_of_le_of_card_le ?_ ?_⟩
  · apply Multiset.le_iff_count.mpr
    intro x
    rw [Multiset.coe_count, count_roots]
    obtain ⟨hyes, hno⟩ := GapChain.count_bound (x := x) hc
    by_cases hx : x ∈ a :: rs
    · have hb := hyes hx
      rw [hmult x] at hb
      have hsub := rootMultiplicity_sub_one_le_derivative_rootMultiplicity p x
      omega
    · by_cases hc' : x ∈ cs
      · have hm : x ∈ p.derivative.roots := (mem_roots hpd).mpr (hderiv x hc')
        have hOne : 1 ≤ p.derivative.rootMultiplicity x := by
          rw [← count_roots]
          exact Multiset.count_pos.mpr hm
        exact (hno hx).trans hOne
      · simp [List.count_eq_zero_of_not_mem hc']
  · have hcard := (derivative_roots_card_and_splits hp hpos).1
    rw [hcard, ← hr, Multiset.coe_card, Multiset.coe_card, hc.length_eq]
    simp

end ChenEndpoint

#print axioms ChenEndpoint.derivative_roots_interlace

