import Mathlib.Analysis.SpecialFunctions.Trigonometric.Chebyshev.RootsExtrema
import Mathlib.Tactic.Linarith

open Polynomial Polynomial.Chebyshev
open scoped Polynomial

namespace ChenEndpoint

noncomputable def normalizedT (n : ℕ) : ℝ[X] :=
  (T ℝ (n : ℤ)).comp (C 2 * X - C 1)

theorem natDegree_normalizedT (n : ℕ) : (normalizedT n).natDegree = n := by
  rw [normalizedT, natDegree_comp, natDegree_T, natDegree_sub_C,
    natDegree_C_mul (by norm_num : (2 : ℝ) ≠ 0), natDegree_X]
  simp

/-- Monic versions of the two normalized Chebyshev level polynomials. -/
noncomputable def monicFiber (n : ℕ) (a : ℝ) : ℝ[X] :=
  (normalizedT n - C a) * C ((normalizedT n).leadingCoeff)⁻¹

private theorem normalizedT_ne_zero {n : ℕ} (hn : 0 < n) : normalizedT n ≠ 0 :=
  ne_zero_of_natDegree_gt (natDegree_normalizedT n ▸ hn)

private theorem fiberNatDegree {n : ℕ} (hn : 0 < n) (a : ℝ) :
    (monicFiber n a).natDegree = n := by
  have h := leadingCoeff_ne_zero.mpr (normalizedT_ne_zero hn)
  rw [monicFiber, mul_comm, natDegree_C_mul (inv_ne_zero h), natDegree_sub_C,
    natDegree_normalizedT]

private theorem fiberMonic {n : ℕ} (hn : 0 < n) (a : ℝ) : (monicFiber n a).Monic := by
  have h := leadingCoeff_ne_zero.mpr (normalizedT_ne_zero hn)
  have hdeg : (C a : ℝ[X]).degree < (normalizedT n).degree := by
    apply lt_of_le_of_lt degree_C_le
    rw [degree_eq_natDegree (normalizedT_ne_zero hn), natDegree_normalizedT]
    exact WithBot.coe_lt_coe.mpr hn
  rw [monicFiber, mul_comm]
  apply monic_C_mul_of_mul_leadingCoeff_eq_one
  rw [leadingCoeff_sub_of_degree_lt hdeg, inv_mul_cancel₀ h]

/-- The degree and coefficient hypotheses for Newton's identities are checked.
This is independent of splitness of these polynomials over the reals. -/
theorem monic_pair_agree_above_constant {n : ℕ} (hn : 2 ≤ n) :
    (monicFiber n 1).Monic ∧ (monicFiber n (-1)).Monic ∧
    (monicFiber n 1).natDegree = n ∧ (monicFiber n (-1)).natDegree = n ∧
    ∀ k : ℕ, 0 < k → (monicFiber n 1).coeff k = (monicFiber n (-1)).coeff k := by
  have hp : 0 < n := by omega
  refine ⟨fiberMonic hp _, fiberMonic hp _, fiberNatDegree hp _, fiberNatDegree hp _, ?_⟩
  intro k hk
  unfold monicFiber
  rw [mul_comm, coeff_C_mul, mul_comm (_ - _), coeff_C_mul, coeff_sub, coeff_sub]
  simp [Polynomial.coeff_one, Nat.ne_of_gt hk]

#print axioms monic_pair_agree_above_constant
end ChenEndpoint
