import ChenGapSign

open Polynomial

namespace ChenEndpoint

theorem GapChain.signed_eval_nonneg {p : ℝ[X]} {a : ℝ} {rs cs : List ℝ}
    (h : GapChain a rs cs) (hs : (a :: rs).Pairwise (· ≤ ·)) (hp : p.Splits)
    (hr : ((a :: rs : List ℝ) : Multiset ℝ) = p.roots)
    (hl : 0 ≤ p.leadingCoeff) (i : ℕ) (hi : i < cs.length) :
    0 ≤ (-1 : ℝ) ^ (cs.length - i) * p.eval cs[i] := by
  rw [h.length_eq, hp.eval_eq_prod_roots, ← hr, Multiset.map_coe, Multiset.prod_coe]
  rw [mul_left_comm]
  exact mul_nonneg hl (h.signed_product_nonneg hs i hi)

/-- If the two real fibers at levels 1 and -1 split, each critical value
lies on the required side of the corresponding level, with alternating signs. -/
theorem both_fibers_critical_values_alternate {f : ℝ[X]} {a b : ℝ} {rs ss : List ℝ}
    (hp : (f - C 1).Splits) (hq : (f + C 1).Splits)
    (hpn : 0 < (f - C 1).natDegree) (hqn : 0 < (f + C 1).natDegree)
    (hlp : 0 ≤ (f - C 1).leadingCoeff) (hlq : 0 ≤ (f + C 1).leadingCoeff)
    (hps : (a :: rs).Pairwise (· ≤ ·)) (hqs : (b :: ss).Pairwise (· ≤ ·))
    (hpr : ((a :: rs : List ℝ) : Multiset ℝ) = (f - C 1).roots)
    (hqr : ((b :: ss : List ℝ) : Multiset ℝ) = (f + C 1).roots) :
    ∃ cs : List ℝ, GapChain a rs cs ∧ GapChain b ss cs ∧
      (cs : Multiset ℝ) = f.derivative.roots ∧
      ∀ (i : ℕ) (hi : i < cs.length), 1 ≤ (-1 : ℝ) ^ (cs.length - i) * f.eval cs[i] := by
  have hd : (f - C 1).derivative = (f + C 1).derivative := by simp
  obtain ⟨cs, hpc, hqc, hcs⟩ := shared_derivative_interlaces hp hq hpn hqn hps hqs hpr hqr hd
  refine ⟨cs, hpc, hqc, by simpa using hcs, ?_⟩
  intro i hi
  have h₁ := hpc.signed_eval_nonneg hps hp hpr hlp i hi
  have h₂ := hqc.signed_eval_nonneg hqs hq hqr hlq i hi
  rcases neg_one_pow_eq_or ℝ (cs.length - i) with hs | hs
  · simp only [hs, one_mul, eval_sub, eval_C] at h₁ ⊢
    linarith
  · simp only [hs, neg_one_mul, eval_add, eval_C] at h₂ ⊢
    linarith

end ChenEndpoint

#print axioms ChenEndpoint.both_fibers_critical_values_alternate

