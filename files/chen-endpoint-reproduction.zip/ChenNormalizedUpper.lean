import ChenBridgeAux
import Mathlib.Order.Fin.Tuple

open Polynomial

namespace ChenEndpoint

private theorem nonempty_sorted_roots {p : ℝ[X]} (hp : p.Splits) (hn : 0 < p.natDegree) :
    ∃ a rs, (a :: rs : List ℝ).Pairwise (· ≤ ·) ∧
      ((a :: rs : List ℝ) : Multiset ℝ) = p.roots := by
  classical
  let L := p.roots.sort (· ≤ ·)
  have hL : (L : Multiset ℝ) = p.roots := Multiset.sort_eq _ _
  have hS : L.Pairwise (· ≤ ·) := Multiset.pairwise_sort _ _
  cases he : L with
  | nil =>
      rw [he] at hL
      have hcard := congrArg Multiset.card hL
      simp [splits_iff_card_roots.mp hp] at hcard
      omega
  | cons a rs =>
      exact ⟨a, rs, he ▸ hS, he ▸ hL⟩

private theorem split_root_order_length {p : ℝ[X]} (hp : p.Splits) {rs : List ℝ}
    (hr : (rs : Multiset ℝ) = p.roots) :
    rs.length = p.natDegree := by
  simpa only [Multiset.coe_card, splits_iff_card_roots.mp hp] using congrArg Multiset.card hr

/-- The actual normalized split-level data imply the sharp bound, without
assuming the ordered critical-point data or either endpoint orientation. -/
theorem normalized_split_levels_endpoint_bound {n : ℕ} (hn : 1 ≤ n)
    {p : ℝ[X]} (hd : p.natDegree = n + 1) (hl : 0 < p.leadingCoeff)
    (hp : (p - C 1).Splits) (hq : (p + C 1).Splits)
    {b : ℝ} (hb0 : 0 ≤ b)
    (hrootp : ∀ x ∈ (p - C 1).roots, x ∈ Set.Icc 0 1)
    (hrootq : ∀ x ∈ (p + C 1).roots, x ∈ Set.Icc 0 b)
    (hb : p.eval b = -1) (h1 : p.eval 1 = 1 ∨ p.eval 1 = -1) :
    Real.cos (Real.pi / (2 * ((n+1 : ℕ) : ℝ))) ^ 2 ≤ b := by
  have hpn : (p - C 1).natDegree = n+1 := by rw [natDegree_sub_C, hd]
  have hqn : (p + C 1).natDegree = n+1 := by rw [natDegree_add_C, hd]
  have hdeg : (C (1 : ℝ)).degree < p.degree := by
    apply degree_C_le.trans_lt
    rw [degree_eq_natDegree (ne_zero_of_natDegree_gt (by omega : 0 < p.natDegree)), hd]
    exact WithBot.coe_lt_coe.mpr (Nat.zero_lt_succ n)
  have hlp : 0 ≤ (p - C 1).leadingCoeff := by simpa only [leadingCoeff_sub_of_degree_lt hdeg] using hl.le
  have hlq : 0 ≤ (p + C 1).leadingCoeff := by simpa only [leadingCoeff_add_of_degree_lt' hdeg] using hl.le
  obtain ⟨a, rs, hps, hpr⟩ := nonempty_sorted_roots hp (by omega)
  obtain ⟨d, ss, hqs, hqr⟩ := nonempty_sorted_roots hq (by omega)
  have hpa : ∀ x ∈ a :: rs, x ∈ Set.Icc 0 1 := by
    intro x hx
    apply hrootp
    simpa only [← hpr, Multiset.mem_coe] using hx
  have hqd : ∀ x ∈ d :: ss, x ∈ Set.Icc 0 b := by
    intro x hx
    apply hrootq
    simpa only [← hqr, Multiset.mem_coe] using hx
  obtain ⟨cs, hpc, hqc, hcs, hsgn⟩ :=
    both_fibers_critical_values_alternate hp hq (by omega) (by omega) hlp hlq hps hqs hpr hqr
  have hlength := split_root_order_length hp hpr
  have hlength' := split_root_order_length hq hqr
  have hcn : cs.length = n := by
    have h := hpc.length_eq
    simp only [List.length_cons, hpn] at hlength
    omega
  have hcup : ∀ x ∈ cs, x ≤ b := hqc.upper fun x hx => (hqd x (List.mem_cons_of_mem _ hx)).2
  have hcpos : ∀ x ∈ cs, 0 < x := by
    intro x hx
    have ha0 := (hpa a (by simp)).1
    have hd0 := (hqd d (by simp)).1
    have hax := hpc.lower x hx
    have hdx := hqc.lower x hx
    by_contra! h
    have ha : a = 0 := by linarith
    have hd' : d = 0 := by linarith
    have hz₁ : (0 : ℝ) ∈ (p - C 1).roots := by rw [← hpr, ha]; simp
    have hz₂ : (0 : ℝ) ∈ (p + C 1).roots := by rw [← hqr, hd']; simp
    have he₁ : (p - C 1).eval 0 = 0 := isRoot_of_mem_roots hz₁
    have he₂ : (p + C 1).eval 0 = 0 := isRoot_of_mem_roots hz₂
    simp only [eval_sub, eval_add, eval_C] at he₁ he₂
    linarith
  let c (i : Fin n) : ℝ := cs[i.val]'(hcn.symm ▸ i.isLt)
  have hcm : Monotone c := by
    intro i j hij
    exact List.SortedLE.getElem_le_getElem_of_le hpc.pairwise.sortedLE hij
  have hcsgn (i : Fin n) : 1 ≤ (-1 : ℝ)^(n-i.val) * p.eval (c i) := by
    have hs := hsgn i.val (hcn.symm ▸ i.isLt)
    have he : cs.length-i.val = n-i.val := congrArg (fun m => m-i.val) hcn
    rw [he] at hs
    exact hs
  have hstr : StrictMono (Fin.cons 0 c) :=
    Fin.strictMono_cons.mpr ⟨fun i => hcpos _ (List.getElem_mem _),
      strictMono_of_mono_critical_alternation hcm hcsgn⟩
  have hsign0 : 1 ≤ (-1 : ℝ)^(n+1) * p.eval 0 := by
    have hA := signed_eval_zero_nonneg hp hlp hpr (fun x hx => (hpa x hx).1)
    have hB := signed_eval_zero_nonneg hq hlq hqr (fun x hx => (hqd x hx).1)
    rw [hlength, hpn] at hA
    rw [hlength', hqn] at hB
    rcases neg_one_pow_eq_or ℝ (n+1) with hs | hs
    · simp only [hs, one_mul, eval_sub, eval_C] at hA ⊢
      linarith
    · simp only [hs, neg_one_mul, eval_add, eval_C] at hB ⊢
      linarith
  have hS : p.derivative.Splits := by
    have := (derivative_roots_card_and_splits hp (by omega : 0 < (p-C 1).natDegree)).2
    simpa using this
  have hT : ∀ a ∈ p.derivative.roots, a ≤ b := by
    intro x hx
    rw [← hcs, Multiset.mem_coe] at hx
    exact hcup x hx
  have hright : p.eval 1 = 1 :=
    right_endpoint_positive_level hp hlp (fun x hx => (hrootp x hx).2) h1
  apply chebyshev_endpoint_bound_of_ordered_critical_data hn hd.le hb0 hstr
  · intro i
    refine Fin.cases ?_ (fun j => ?_) i
    · simpa using (show (0 : ℝ) ∈ Set.Icc 0 b from ⟨le_rfl,hb0⟩)
    · simpa only [Fin.cons_succ] using
        (show c j ∈ Set.Icc 0 b from ⟨(hcpos _ (List.getElem_mem _)).le, hcup _ (List.getElem_mem _)⟩)
  · intro i
    refine Fin.cases ?_ (fun j => ?_) i
    · have he : (-1 : ℝ)^(n+3) = (-1 : ℝ)^(n+1) := by
        rw [show n+3 = (n+1)+2 by omega, pow_add]
        norm_num
      simpa [he] using hsign0
    · have he : n+3 - j.succ.val = (n-j.val)+2 := by
        simp only [Fin.val_succ]
        have := j.isLt
        omega
      rw [he, pow_add]
      simpa using hcsgn j
  · exact right_tail_between_levels (by omega) hl hS hT hb hright

end ChenEndpoint

#print axioms ChenEndpoint.normalized_split_levels_endpoint_bound

