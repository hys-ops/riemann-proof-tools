import Mathlib.Analysis.Calculus.LocalExtr.Polynomial
import Mathlib.Algebra.Polynomial.Splits

open Polynomial

namespace ChenEndpoint

/-- A positive-degree split real polynomial loses exactly one root, counted with
multiplicity, under differentiation. In particular its derivative still splits. -/
theorem derivative_roots_card_and_splits {p : ℝ[X]} (hp : p.Splits)
    (hpos : 0 < p.natDegree) :
    p.derivative.roots.card = p.roots.card - 1 ∧ p.derivative.Splits := by
  have hcount : p.roots.card = p.natDegree := splits_iff_card_roots.mp hp
  have hdegree := natDegree_derivative p
  have hlo := p.card_roots_le_derivative
  have hhi := p.derivative.card_roots'
  have heq : p.derivative.roots.card = p.natDegree - 1 := by omega
  exact ⟨by rw [heq, hcount], splits_iff_card_roots.mpr (heq.trans hdegree.symm)⟩

/-- An adjacent gap yields a derivative root. If the endpoints coincide, count
the repeated endpoint instead of applying Rolle on an empty open interval. -/
theorem exists_derivative_root_between {p : ℝ[X]} {a b : ℝ} (hab : a ≤ b)
    (ha : p.IsRoot a) (hb : p.IsRoot b)
    (hrepeated : a = b → 1 < p.rootMultiplicity a) :
    ∃ c ∈ Set.Icc a b, p.derivative.IsRoot c := by
  obtain hlt | heq := lt_or_eq_of_le hab
  · obtain ⟨c, hc, hz⟩ := exists_deriv_eq_zero hlt p.continuousOn (ha.trans hb.symm)
    exact ⟨c, ⟨hc.1.le, hc.2.le⟩, by simpa only [Polynomial.IsRoot, ← p.deriv] using hz⟩
  · have hne : p ≠ 0 := by
      intro hp
      have hr := hrepeated heq
      simp [hp] at hr
    have ha' := (one_lt_rootMultiplicity_iff_isRoot hne).mp (hrepeated heq)
    exact ⟨a, ⟨le_rfl, hab⟩, ha'.2⟩

end ChenEndpoint

#print axioms ChenEndpoint.derivative_roots_card_and_splits
#print axioms ChenEndpoint.exists_derivative_root_between

