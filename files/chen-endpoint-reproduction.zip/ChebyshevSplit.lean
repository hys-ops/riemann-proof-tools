import ChebyshevMonicFibers
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Complex

open Polynomial Polynomial.Chebyshev
open scoped Polynomial

namespace ChenEndpoint

/-- Chebyshev has real preimages of its two real extremal values even over the
complex numbers. -/
private theorem im_eq_zero_of_eval_T {n : ℕ} (hn : 0 < n) {z : ℂ}
    (hz : (T ℂ (n : ℤ)).eval z = 1 ∨ (T ℂ (n : ℤ)).eval z = -1) : z.im = 0 := by
  obtain ⟨w, rfl⟩ := Complex.cos_surjective z
  rw [T_complex_cos] at hz
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast (Nat.ne_of_gt hn)
  have hi : ((n : ℂ) * w).im = 0 := by
    push_cast at hz
    rcases hz with hp | hm
    · obtain ⟨k, hk⟩ := Complex.cos_eq_one_iff.mp hp
      rw [← hk]
      simp [Complex.mul_im]
    · obtain ⟨k, hk⟩ := Complex.cos_eq_neg_one_iff.mp hm
      rw [← hk]
      simp [Complex.mul_im]
  have hw : w.im = 0 := by
    apply (mul_eq_zero.mp _).resolve_left hnR
    simpa [Complex.mul_im] using hi
  have hre : (w.re : ℂ) = w := Complex.ext rfl (by simpa using hw.symm)
  rw [← hre, ← Complex.ofReal_cos]
  simp

/-- Both normalized level polynomials split over the real field, counting their
roots with multiplicity. -/
theorem monicFiber_splits {n : ℕ} (hn : 0 < n) {a : ℝ} (ha : a = 1 ∨ a = -1) :
    (monicFiber n a).Splits := by
  let i : ℝ →+* ℂ := Complex.ofRealHom
  apply Polynomial.Splits.of_splits_map i (IsAlgClosed.splits _)
  intro z hz
  have hl : (normalizedT n).leadingCoeff ≠ 0 := by
    apply leadingCoeff_ne_zero.mpr
    exact ne_zero_of_natDegree_gt (natDegree_normalizedT n ▸ hn)
  have he : ((T ℂ (n : ℤ)).eval (2*z-1) - (a : ℂ)) *
      (((normalizedT n).leadingCoeff : ℂ)⁻¹) = 0 := by
    have hr := (Polynomial.mem_roots'.mp hz).2
    simpa [Polynomial.IsRoot, monicFiber, normalizedT, i, Polynomial.map_comp,
      map_T, Polynomial.eval_comp] using hr
  have hzT : (T ℂ (n : ℤ)).eval (2*z-1) = (a : ℂ) := by
    apply sub_eq_zero.mp
    exact (mul_eq_zero.mp he).resolve_right (inv_ne_zero (by exact_mod_cast hl))
  have harg : (2*z-1).im = 0 := by
    apply im_eq_zero_of_eval_T hn
    rcases ha with rfl | rfl <;> simp [hzT]
  have hzIm : z.im = 0 := by
    simp [Complex.sub_im, Complex.mul_im] at harg
    linarith
  refine ⟨z.re, Complex.ext ?_ ?_⟩
  · simp [i]
  · simp [i, hzIm]

#print axioms monicFiber_splits

end ChenEndpoint

