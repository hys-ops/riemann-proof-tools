import ChebyshevFiber
import ChebyshevSplit
import ChenNewton

open Polynomial Polynomial.Chebyshev
open scoped Polynomial

namespace ChenEndpoint

theorem mem_roots_monicFiber_iff {n : ℕ} (hn : 0 < n) (a x : ℝ) :
    x ∈ (monicFiber n a).roots ↔ (T ℝ (n : ℤ)).eval (2*x-1) = a := by
  have hl : (normalizedT n).leadingCoeff ≠ 0 := by
    apply leadingCoeff_ne_zero.mpr
    exact ne_zero_of_natDegree_gt (natDegree_normalizedT n ▸ hn)
  have hp : monicFiber n a ≠ 0 := by
    unfold monicFiber
    apply mul_ne_zero _ (by simpa using inv_ne_zero hl)
    intro h
    have hc := sub_eq_zero.mp h
    have hd := congrArg natDegree hc
    simp [natDegree_normalizedT] at hd
    omega
  rw [mem_roots hp]
  change (monicFiber n a).eval x = 0 ↔ _
  unfold monicFiber
  rw [eval_mul, eval_sub, eval_C, eval_C, mul_eq_zero, or_iff_left (inv_ne_zero hl), sub_eq_zero]
  simp [normalizedT, eval_comp]

theorem greatest_pos_fiber {n : ℕ} (hn : 2 ≤ n) :
    IsGreatest {x : ℝ | (T ℝ (n : ℤ)).eval (2*x - 1) = 1} 1 := by
  have hn0 : n ≠ 0 := by omega
  refine ⟨?_, ?_⟩
  · change (T ℝ (n : ℤ)).eval (2*1-1) = 1
    norm_num
  · intro x hx
    change (T ℝ (n : ℤ)).eval (2*x-1) = 1 at hx
    obtain ⟨k, _, _, hcos⟩ := (eval_T_real_eq_one_iff hn0 _).1 hx
    have hle := Real.cos_le_one ((k : ℝ) * Real.pi / n)
    linarith

/-- The normalized Chebyshev witnesses attain the candidate maximum gap.
The theorem states attainment only, not the upper bound for all lists. -/
theorem chebyshev_attainment {n : ℕ} (hn : 2 ≤ n) :
    let p := monicFiber n 1
    let m := monicFiber n (-1)
    p.roots.card = n ∧ m.roots.card = n ∧
    (∀ k, 0 < k → k < n → powerSum p.roots k = powerSum m.roots k) ∧
    IsGreatest {x : ℝ | x ∈ p.roots} 1 ∧
    IsGreatest {x : ℝ | x ∈ m.roots} (Real.cos (Real.pi / (2*(n : ℝ))) ^ 2) := by
  dsimp only
  have hnp : 0 < n := by omega
  have hp := monicFiber_splits hnp (a := 1) (Or.inl rfl)
  have hm := monicFiber_splits hnp (a := -1) (Or.inr rfl)
  obtain ⟨_, _, hdp, hdm, _⟩ := monic_pair_agree_above_constant hn
  refine ⟨(splits_iff_card_roots.mp hp).trans hdp, (splits_iff_card_roots.mp hm).trans hdm,
    fun _ hk hkn => monicFiber_powerSums_eq_of_splits hn hp hm hk hkn, ?_, ?_⟩
  · convert greatest_pos_fiber hn using 1
    ext x
    exact mem_roots_monicFiber_iff hnp 1 x
  · convert greatest_neg_fiber hn using 1
    ext x
    exact mem_roots_monicFiber_iff hnp (-1) x

#print axioms chebyshev_attainment
end ChenEndpoint

