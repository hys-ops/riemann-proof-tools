import ChenCrossings

namespace ChenEndpoint

/-- Select a single strict amplitude below 1 that beats both endpoint
obstructions. This avoids any limiting argument in the crossing proof. -/
theorem exists_comparison_amplitude {a b : ℝ} (ha : -1 < a) (hb : b < 1) :
    ∃ amp : ℝ, 0 < amp ∧ amp < 1 ∧ 0 < a + amp ∧ b - amp < 0 := by
  let m := max 0 (max (-a) b)
  have hm₀ : 0 ≤ m := le_max_left _ _
  have hm₁ : m < 1 := max_lt (by norm_num) (max_lt (by linarith) hb)
  have hl : -a ≤ m := (le_max_left _ _).trans (le_max_right _ _)
  have hr : b ≤ m := (le_max_right _ _).trans (le_max_right _ _)
  refine ⟨(1 + m) / 2, ?_, ?_, ?_, ?_⟩ <;> linarith

/-- A comparison function bounded by 1 cannot erase either orientation of
a critical value of magnitude at least 1 when scaled by a strict amplitude. -/
theorem perturbation_preserves_margin {a b amp sign : ℝ}
    (h₀ : 0 ≤ amp) (h₁ : amp < 1)
    (hs : sign = 1 ∨ sign = -1)
    (ha : 1 ≤ sign * a) (hb : |b| ≤ 1) :
    0 < sign * (a - amp * b) := by
  obtain ⟨hb₁, hb₂⟩ := abs_le.mp hb
  rcases hs with rfl | rfl
  · simp only [one_mul] at ha ⊢
    linarith [mul_le_mul_of_nonneg_left hb₂ h₀]
  · simp only [neg_one_mul] at ha ⊢
    linarith [mul_le_mul_of_nonneg_left hb₁ h₀]

end ChenEndpoint

#print axioms ChenEndpoint.exists_comparison_amplitude
#print axioms ChenEndpoint.perturbation_preserves_margin

