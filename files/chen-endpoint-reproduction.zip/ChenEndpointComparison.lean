import ChenAffineChebyshev

open Polynomial

namespace ChenEndpoint

/-- Sharp endpoint inequality, once the ordered critical-value data and the
strict right-tail bounds of the normalized polynomial have been supplied. -/
theorem chebyshev_endpoint_bound_of_ordered_critical_data {n : ℕ} (hn : 1 ≤ n)
    {p : ℝ[X]} (hp : p.natDegree ≤ n+1)
    {b : ℝ} (hb₀ : 0 ≤ b)
    {t : Fin (n+1) → ℝ} (ht : StrictMono t)
    (htCore : ∀ i, t i ∈ Set.Icc 0 b)
    (hpCore : ∀ i, 1 ≤ (-1 : ℝ) ^ (n+3-i.val) * p.eval (t i))
    (hpTail : ∀ x ∈ Set.Ioo b 1, -1 < p.eval x ∧ p.eval x < 1) :
    Real.cos (Real.pi / (2 * ((n+1 : ℕ) : ℝ))) ^ 2 ≤ b := by
  by_contra! hb
  obtain ⟨u, v, Q, hbu, huv, hv1, hQ, hQu, hQv, hQbound⟩ :=
    exists_affine_chebyshev_comparator (n := n+1) (by omega) hb₀ hb
  let r (i : Fin (n+2+1)) : ℝ :=
    if h : i.val < n+1 then t ⟨i.val, h⟩ else if i.val = n+1 then u else v
  have hmono : StrictMono r := by
    intro i j hij
    have hval : i.val < j.val := hij
    by_cases hj : j.val < n+1
    · have hi : i.val < n+1 := hval.trans hj
      simp only [r, dif_pos hi, dif_pos hj]
      exact ht hval
    · by_cases hi : i.val < n+1
      · simp only [r, dif_pos hi, dif_neg hj]
        have hb := (htCore ⟨i.val, hi⟩).2
        split_ifs
        · exact hb.trans_lt hbu
        · exact hb.trans_lt (hbu.trans huv)
      · have hi' : i.val = n+1 := by have := j.isLt; omega
        have hj' : j.val ≠ n+1 := by omega
        simpa only [r, dif_neg hi, dif_neg hj, if_pos hi', if_neg hj'] using huv
  have hru : r ⟨n+1, by omega⟩ = u := by simp [r]
  have hrv : r ⟨n+2, by omega⟩ = v := by simp [r]
  apply comparison_alternation_impossible hp hQ.le hmono
  · intro i hi
    have hh : i.val < n+1 := by omega
    simpa only [r, dif_pos hh] using hpCore ⟨i.val, hh⟩
  · intro i hi
    have hh : i.val < n+1 := by omega
    simp only [r, dif_pos hh]
    exact hQbound _ ⟨(htCore _).1, (htCore _).2.trans (hbu.trans huv).le⟩
  · rw [hru]
    exact (hpTail u ⟨hbu, huv.trans hv1⟩).1
  · rw [hrv]
    exact (hpTail v ⟨hbu.trans huv, hv1⟩).2
  · rwa [hru]
  · rwa [hrv]

end ChenEndpoint

#print axioms ChenEndpoint.chebyshev_endpoint_bound_of_ordered_critical_data

