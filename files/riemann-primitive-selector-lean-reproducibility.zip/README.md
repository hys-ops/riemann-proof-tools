# A primitive-row input for the exact PairEx consumer

Upstream revision `40e56bab026552e089d7afcfeff08d2defb9c005`. The production source consists of PrimitivePairCore.lean and PairExOfPrimitiveSelector.lean. The new theorem is conditional on a primitive selection statement. No new assumption is inserted into the original closed Riemann-hypothesis argument by the additive patch.

## Selector input

PrimitivePairSelector chooses q in the original first prime set and d in the original second prime set conditional on q, with 8M<q. For every base character modulo 8M (and for both second-stage masks) it supplies one primitive representative, nonprincipality, the conductor and zero-free conditions, an all-integer masked Jacobi factorization, and an estimate on the explicit finite sign sum S. The parameters X=Y^K, z=Y^(ε/5), z′=z(log Y)^2 are fixed throughout selection. The original pair_exists also quantifies over independent X and z′. This adapter uses no such extra uniformity. The endpoint K=1 can also be selected at a larger K>1 provided the finite-sum cutoff is handled for the requested X. Equivalently, prove the selection directly with K=1 (the prime-balance construction examines primes up to the specified cutoff and works for this K).

The selector contains no Gchi or log derivative conclusion, and does not assume Rows, GoodQ, GoodD or PairGood. Its S estimate at the original tolerance follows on paper from the prime-prefix construction and the decomposition into prime powers. It is an explicit input to this Lean verification. In particular, existence cannot be obtained by deleting that input. Zero-density, Jacobi-character distribution, and arithmetic-progression supply used for that construction must still be provided. The retained BoxOfS lemma converts the finite sum into the window estimate and logarithmic-derivative bound.

## Verified code

BoxOfS is instantiated at ε and τ=ε/2. The core proves both heights fit its range for all sufficiently large Y, checks the CRT membership gives Rows, and uses primitive-character uniqueness to handle every character in BoxAll. The original second branch with any real primitive base of conductor dividing 8M is preserved.

The focused replay checks the core and the final consumer using the pinned original definitions of PChar, Induces, WinPair, PairGood and PairEx, the original rows_of_mem and ind_unique proof bodies, and original signatures for box_of_S, ind_drop and kappa4. Both Lean 4.34.1 invocations exit successfully. The two reports print only propext, Classical.choice and Quot.sound. Some unchanged proof steps produce style/deprecation warnings. The replay is separate from a build of the full upstream dependency graph.

AddPrimitivePairRoute.patch adds both modules, preserving all existing proofs. ConditionalPairEx.patch instead edits the pinned pairEx module and introduces its alternative conditional theorem. This second patch is a dependency-comparison variant; downstream users of the original closed QH.pairEx require a proved selector to wire this replacement. Both patches have been checked, applied in isolated directories, and their resulting files compared to the delivered source.

## Counting

In the induced dependency graph inside MeanSquareBounds, compare the original consumer with the branch that receives its selection proof as an input. Eight previously counted mean-square / maximal modules total 1,364 source lines. Five staging modules total another 593. Their combined 1,957 source lines describe a bypassed original route, not a verified net reduction. Four other modules for counting zero exceptions and finding/estimating the progression total 184 original lines and are still used in the written selector construction. Primitive-character preparation used parts of Stage1Succ and CharOf, so those preparations must be carried over if the selector is fully formalized without importing the original stages.

The original consumer has 171 physical lines, the conditional replacement 166, and its new core has 116. The source patch therefore adds a net 111 physical lines when the unchanged old modules remain on disk. The two complete proof approaches and the standalone end-to-end length of the new arithmetic selection have not been compared. The attached per-module counts refer to this one directory, not to a whole-repository import-closure measurement.
