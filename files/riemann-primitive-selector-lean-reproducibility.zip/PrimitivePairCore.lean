import Development.AutomorphicArithmetic.MeanSquareBounds.PrimeSetTwoBounds
import Development.AutomorphicArithmetic.MeanSquareBounds.IndUnique
import Development.AutomorphicArithmetic.MeanSquareBounds.RowsOfMem
import Development.AutomorphicArithmetic.MeanSquareBounds.BoxOfS

open Finset Formalism.HermitianLattices.ZeroFreeRegionGL2

namespace QH

/-- Data available before assembling a Box. It contains a finite sign-sum
estimate and the original zero-free certificate for the primitive character. -/
def PrimitiveSample (Q Y X τ : ℝ) (p m : ℕ) (f : ℕ → ℂ) : Prop :=
  ∃ (N : ℕ) (_ : NeZero N) (χ : DirichletCharacter ℂ N) (κ : ℕ → ℂ),
    Ind χ f m ∧ GoodC Q χ ∧ (∀ n : ℕ, χ (n : ZMod N) = κ n * J p n) ∧
    ∀ y ∈ Set.Icc Y X, ‖S (X ^ 400) y p κ‖ ≤ y ^ (1 / 2 + τ) / 2

/-- Only the two specific moduli, ranges and windows used by pairEx. A
second-stage prime is selected after the first. No fraction of rows is asserted. -/
def PrimitivePairSelector : Prop :=
  ∀ (M : ℕ), 0 < M → ∀ ε K : ℝ, 0 < ε → ε < 1 / 52 → 1 ≤ K →
    ∃ Y₀ : ℝ, ∀ Y ≥ Y₀,
      let n := 8 * M
      let z := Y ^ (ε / 5)
      let z' := z * Real.log Y ^ 2
      ∃ q ∈ primePairSetFirst z, ∃ d ∈ primeSetTwoBounds z z' q,
        n < q ∧
        (∀ ξ : DirichletCharacter ℂ n,
          PrimitiveSample (n * Real.exp z) Y (Y ^ K) (ε / 2) q (n * q)
            (fun a => ξ a * J q a)) ∧
        (∀ (ξ : DirichletCharacter ℂ n) (i : ℕ), i ≤ 1 →
          PrimitiveSample (n * Real.exp (z + z')) Y (Y ^ K) (ε / 2) d (n * q * d)
            (fun a => ξ a * J q a ^ i * J d a))

private theorem sample_box {Q C Y X τ : ℝ} {p m : ℕ} {f : ℕ → ℂ} (hm : m ≠ 0)
    (hbuild : ∀ (N : ℕ) [NeZero N] (χ : DirichletCharacter ℂ N) (κ : ℕ → ℂ),
      GoodC Q χ → (∀ n : ℕ, χ (n : ZMod N) = κ n * J p n) →
      (∀ y ∈ Set.Icc Y X, ‖S (X ^ 400) y p κ‖ ≤ y ^ (1 / 2 + τ) / 2) → Box Q C τ Y X χ)
    (w : PrimitiveSample Q Y X τ p m f) : BoxAll Q C τ Y X f m := by
  obtain ⟨N, hN, χ, κ, hI, hg, he, hs⟩ := w
  letI : NeZero N := hN
  have hb := hbuild N χ κ hg he hs
  intro N' _ χ' hI'
  have eq := ind_unique N' N m χ' χ hm hI'.1 hI.1
    (fun a ha => (hI'.2 a ha).trans (hI.2 a ha).symm)
  obtain ⟨rfl, h⟩ := Sigma.mk.inj_iff.1 eq
  obtain rfl := eq_of_heq h
  exact hb

private theorem selector_heights (n : ℕ) (hn : 0 < n) (ε : ℝ) (hε : 0 < ε) :
    ∃ Y₀ : ℝ, ∀ Y ≥ Y₀,
      let z := Y ^ (ε / 5)
      let z' := z * Real.log Y ^ 2
      0 < z ∧ 2 * z ≤ z' ∧
      (Y ^ (ε / 6) ≤ Real.log (n * Real.exp z) ∧ Real.log (n * Real.exp z) ≤ Y ^ (ε / 4)) ∧
      (Y ^ (ε / 6) ≤ Real.log (n * Real.exp (z + z')) ∧
        Real.log (n * Real.exp (z + z')) ≤ Y ^ (ε / 4)) := by
  have he := (isLittleO_log_rpow_rpow_atTop (2 : ℝ) (show 0 < ε / 20 by linarith)).bound
    (c := (1 / 3 : ℝ)) (by positivity)
  have hlarge := (tendsto_rpow_atTop (show 0 < ε / 5 by linarith)).eventually_ge_atTop
    (Real.log (n : ℝ))
  obtain ⟨Y₀, H⟩ := Filter.eventually_atTop.1
    (he.and (hlarge.and (Filter.eventually_ge_atTop (Real.exp 2))))
  refine ⟨Y₀, fun Y hY => ?_⟩
  obtain ⟨hpow, hnz, hY2⟩ := H Y hY
  have hYpos : 0 < Y := lt_of_lt_of_le (Real.exp_pos _) hY2
  have hY1 : 1 ≤ Y := (Real.one_le_exp (by norm_num : (0:ℝ) ≤ 2)).trans hY2
  have hL : 2 ≤ Real.log Y := (Real.le_log_iff_exp_le hYpos).2 hY2
  have hnpos : 0 < (n : ℝ) := by exact_mod_cast hn
  have hnlog : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by exact_mod_cast hn)
  have hw : 0 < Y ^ (ε / 5) := Real.rpow_pos_of_pos hYpos _
  have hl : Y ^ (ε / 6) ≤ Y ^ (ε / 5) := Real.rpow_le_rpow_of_exponent_le hY1 (by linarith)
  have hbound : (Real.log Y)^2 ≤ (1/3:ℝ) * Y ^ (ε/20) := by
    simpa [Real.rpow_two, Real.norm_of_nonneg (sq_nonneg (Real.log Y)),
      Real.norm_of_nonneg (Real.rpow_nonneg hYpos.le (ε / 20))] using hpow
  have split : Y ^ (ε / 4) = Y ^ (ε / 5) * Y ^ (ε / 20) := by
    rw [← Real.rpow_add hYpos]; congr 1; ring
  have hzl : 2 * Y ^ (ε / 5) ≤ Y ^ (ε / 5) * Real.log Y ^ 2 := by
    calc 2 * Y ^ (ε / 5) = Y ^ (ε / 5) * 2 := mul_comm _ _
      _ ≤ Y ^ (ε / 5) * Real.log Y ^ 2 := mul_le_mul_of_nonneg_left (by nlinarith) hw.le
  have hge : 0 ≤ Y ^ (ε / 5) * Real.log Y ^ 2 := by positivity
  have hcap := mul_le_mul_of_nonneg_left hbound hw.le
  dsimp only
  rw [Real.log_mul hnpos.ne' (Real.exp_pos _).ne', Real.log_exp,
    Real.log_mul hnpos.ne' (Real.exp_pos _).ne', Real.log_exp, split]
  exact ⟨hw, hzl, ⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩

theorem rows_from_primitive_selector (select : PrimitivePairSelector) :
    ∃ C : ℝ, 0 < C ∧ ∀ (M : ℕ), 0 < M → ∀ ε K : ℝ,
    0 < ε → ε < 1 / 52 → 1 ≤ K → ∃ Y₀ : ℝ, ∀ Y ≥ Y₀,
      let z := Y ^ (ε / 5)
      let z' := z * Real.log Y ^ 2
      ∃ q d : ℕ, Rows z z' q d ∧ 8 * M < q ∧
        GoodQ (8 * M) C (ε / 2) Y (Y ^ K) z q ∧
        GoodD (8 * M) C (ε / 2) Y (Y ^ K) z z' q d := by
  obtain ⟨C, hC, hbox⟩ := box_of_S
  refine ⟨C, hC, fun M hM ε K hε hε52 hK => ?_⟩
  have hn : 0 < 8 * M := by omega
  obtain ⟨Ys, hs⟩ := select M hM ε K hε hε52 hK
  obtain ⟨Yt, ht⟩ := selector_heights _ hn ε hε
  obtain ⟨Yb, hb⟩ := hbox ε (ε/2) K hε (by linarith) (by linarith) hK
  refine ⟨max (max Ys Yt) Yb, fun Y hY => ?_⟩
  have hYs := (le_max_left Ys Yt).trans ((le_max_left _ _).trans hY)
  have hYt := (le_max_right Ys Yt).trans ((le_max_left _ _).trans hY)
  have hYb := (le_max_right _ _).trans hY
  obtain ⟨q, hq, d, hd, hnq, hqraw, hdraw⟩ := hs Y hYs
  obtain ⟨hz, hzz, hqRange, hdRange⟩ := ht Y hYt
  have hR := rows_of_mem _ _ _ _ hz hzz hq hd
  have hmQ : 8 * M * q ≠ 0 := Nat.ne_of_gt (Nat.mul_pos hn hR.q_prime.pos)
  have hmD : 8 * M * q * d ≠ 0 := Nat.mul_ne_zero hmQ hR.d_prime.ne_zero
  refine ⟨q, d, hR, hnq, ?_, ?_⟩
  · intro ξ
    exact sample_box hmQ (fun N _ χ κ => hb Y hYb _ N χ q κ hqRange.1 hqRange.2) (hqraw ξ)
  · intro ξ i hi
    exact sample_box hmD (fun N _ χ κ => hb Y hYb _ N χ d κ hdRange.1 hdRange.2) (hdraw ξ i hi)

end QH
