import Development.AutomorphicArithmetic.MeanSquareBounds.PrimeSetTwoBounds

open Finset Formalism.HermitianLattices.ZeroFreeRegionGL2

namespace QH

theorem rows_of_mem :
    ∀ (z z' : ℝ) (q d : ℕ), 0 < z → 2 * z ≤ z' → q ∈ primePairSetFirst z → d ∈ primeSetTwoBounds z z' q → Rows z z' q d := by
  intro z z' q d hz hzz hq hd
  have hhalf : ∀ t : ℝ, Real.exp t ^ (1 / 2 : ℝ) = Real.exp (t / 2) := by
    intro t
    rw [← Real.exp_mul]
    congr 1
    ring
  simp only [primePairSetFirst, PPset, primeSetTwoBounds, mem_filter, mem_Icc, hhalf] at hq hd
  obtain ⟨⟨_, hq2⟩, hqp, hqm, hqg⟩ := hq
  obtain ⟨⟨_, hd2⟩, hdp, hdm, hdv, hdg⟩ := hd
  have hq0 : (0 : ℝ) < q := by exact_mod_cast hqp.pos
  have hd0 : (0 : ℝ) < d := by exact_mod_cast hdp.pos
  have hqle : (q : ℝ) ≤ Real.exp z := (Nat.le_floor_iff (Real.exp_pos z).le).1 hq2
  have hdle : (d : ℝ) ≤ Real.exp z' := (Nat.le_floor_iff (Real.exp_pos z').le).1 hd2
  refine ⟨hqp, by omega, (Real.lt_log_iff_exp_lt hq0).2 hqg, (Real.log_le_iff_le_exp hq0).2 hqle,
    hdp, hdm, (Real.lt_log_iff_exp_lt hd0).2 hdg, (Real.log_le_iff_le_exp hd0).2 hdle, ?_, ?_⟩
  · have h1 : Real.exp z ≤ Real.exp (z' / 2) := Real.exp_le_exp.2 (by linarith)
    have h2 : (q : ℝ) < d := lt_of_le_of_lt (hqle.trans h1) hdg
    exact_mod_cast h2
  · intro p hp hp2 hpz
    apply Nat.mod_eq_zero_of_dvd
    refine Dvd.dvd.trans ?_ hdv
    unfold oddM
    rcases hpz with h | h
    · refine Dvd.dvd.mul_left ?_ _
      refine Finset.dvd_prod_of_mem (fun p : ℕ => p) ?_
      rw [mem_filter, mem_Icc]
      have h2 := hp.two_le
      exact ⟨⟨by omega, Nat.le_floor h⟩, hp⟩
    · rw [h]
      exact Dvd.intro _ rfl

end QH

namespace QH

theorem ind_unique :
    ∀ (N N' M : ℕ) [NeZero N] [NeZero N'] (ψ : DirichletCharacter ℂ N) (ψ' : DirichletCharacter ℂ N'), M ≠ 0 →
      ψ.IsPrimitive → ψ'.IsPrimitive → (∀ n : ℕ, n.Coprime M → ψ (n : ZMod N) = ψ' (n : ZMod N')) →
      (⟨N, ψ⟩ : Σ n : ℕ, DirichletCharacter ℂ n) = ⟨N', ψ'⟩ := by
  intro N N' M _ _ ψ ψ' hM hψ hψ' h
  have hN : N ≠ 0 := NeZero.ne N
  have hN' : N' ≠ 0 := NeZero.ne N'
  haveI : NeZero (N * N' * M) := ⟨mul_ne_zero (mul_ne_zero hN hN') hM⟩
  haveI : NeZero (N * N') := ⟨mul_ne_zero hN hN'⟩
  haveI : NeZero (N' * N) := ⟨mul_ne_zero hN' hN⟩
  have hL1 : N ∣ N * N' * M := (Nat.dvd_mul_right N N').mul_right M
  have hL2 : N' ∣ N * N' * M := (Nat.dvd_mul_left N' N).mul_right M
  have hLM : M ∣ N * N' * M := Nat.dvd_mul_left M _
  have hA : N * N' ∣ N * N' * M := Nat.dvd_mul_right _ _
  have hB : N' * N ∣ N * N' * M := ⟨M, by ring⟩
  have key : ψ.changeLevel hL1 = ψ'.changeLevel hL2 := by
    ext a
    rw [DirichletCharacter.changeLevel_eq_cast_of_dvd, DirichletCharacter.changeLevel_eq_cast_of_dvd]
    have hc : ((a : ZMod (N * N' * M)).val).Coprime (N * N' * M) := ZMod.val_coe_unit_coprime a
    rw [← ZMod.natCast_zmod_val (a : ZMod (N * N' * M)), ZMod.cast_natCast hL1,
      ZMod.cast_natCast hL2]
    exact h _ (Nat.Coprime.coprime_dvd_right hLM hc)
  have k1 : ψ.changeLevel (Nat.dvd_mul_right N N') = ψ'.changeLevel (Nat.dvd_mul_left N' N) := by
    apply DirichletCharacter.changeLevel_injective hA
    rw [← DirichletCharacter.changeLevel_trans, ← DirichletCharacter.changeLevel_trans]
    exact key
  have k2 : ψ'.changeLevel (Nat.dvd_mul_right N' N) = ψ.changeLevel (Nat.dvd_mul_left N N') := by
    apply DirichletCharacter.changeLevel_injective hB
    rw [← DirichletCharacter.changeLevel_trans, ← DirichletCharacter.changeLevel_trans]
    exact key.symm
  have f1 := DirichletCharacter.factorsThrough_gcd ψ ψ' k1
  have f2 := DirichletCharacter.factorsThrough_gcd ψ' ψ k2
  have e1 : ψ.conductor = N := hψ
  have e2 : ψ'.conductor = N' := hψ'
  have c1 : ψ.conductor ≤ N.gcd N' := Nat.sInf_le f1
  have c2 : ψ'.conductor ≤ N'.gcd N := Nat.sInf_le f2
  rw [e1] at c1
  rw [e2] at c2
  have g1 : N.gcd N' = N := le_antisymm (Nat.gcd_le_left _ (Nat.pos_of_ne_zero hN)) c1
  have g2 : N'.gcd N = N' := le_antisymm (Nat.gcd_le_left _ (Nat.pos_of_ne_zero hN')) c2
  have hEq : N = N' := by rw [← g1, Nat.gcd_comm, g2]
  subst hEq
  have : ψ = ψ' := DirichletCharacter.changeLevel_injective (Nat.dvd_mul_right N N) k1
  subst this
  rfl

end QH

namespace QH

/-- Data available before assembling a Box. It contains a finite sign-sum
estimate and the original zero-free certificate for the primitive character. -/
def PrimitiveSample (Q Y X τ : ℝ) (p m : ℕ) (f : ℕ → ℂ) : Prop :=
  ∃ (N : ℕ) (_ : NeZero N) (χ : DirichletCharacter ℂ N) (κ : ℕ → ℂ),
    Ind χ f m ∧ GoodC Q χ ∧ (∀ n : ℕ, χ (n : ZMod N) = κ n * J p n) ∧
    ∀ y ∈ Set.Icc Y X, ‖S (X ^ 400) y p κ‖ ≤ y ^ (1 / 2 + τ) / 2

/-- Only the two specific moduli, ranges and windows used by pairEx. A
second-stage prime is selected after the first. No fraction of rows is asserted. -/
def PrimitivePairSelector : Prop :=
  ∀ (M : ℕ), 0 < M → ∀ ε K : ℝ, 0 < ε → ε < 1 / 52 → 1 ≤ K →
    ∃ Y₀ : ℝ, ∀ Y ≥ Y₀,
      let n := 8 * M
      let z := Y ^ (ε / 5)
      let z' := z * Real.log Y ^ 2
      ∃ q ∈ primePairSetFirst z, ∃ d ∈ primeSetTwoBounds z z' q,
        n < q ∧
        (∀ ξ : DirichletCharacter ℂ n,
          PrimitiveSample (n * Real.exp z) Y (Y ^ K) (ε / 2) q (n * q)
            (fun a => ξ a * J q a)) ∧
        (∀ (ξ : DirichletCharacter ℂ n) (i : ℕ), i ≤ 1 →
          PrimitiveSample (n * Real.exp (z + z')) Y (Y ^ K) (ε / 2) d (n * q * d)
            (fun a => ξ a * J q a ^ i * J d a))

private theorem sample_box {Q C Y X τ : ℝ} {p m : ℕ} {f : ℕ → ℂ} (hm : m ≠ 0)
    (hbuild : ∀ (N : ℕ) [NeZero N] (χ : DirichletCharacter ℂ N) (κ : ℕ → ℂ),
      GoodC Q χ → (∀ n : ℕ, χ (n : ZMod N) = κ n * J p n) →
      (∀ y ∈ Set.Icc Y X, ‖S (X ^ 400) y p κ‖ ≤ y ^ (1 / 2 + τ) / 2) → Box Q C τ Y X χ)
    (w : PrimitiveSample Q Y X τ p m f) : BoxAll Q C τ Y X f m := by
  obtain ⟨N, hN, χ, κ, hI, hg, he, hs⟩ := w
  letI : NeZero N := hN
  have hb := hbuild N χ κ hg he hs
  intro N' _ χ' hI'
  have eq := ind_unique N' N m χ' χ hm hI'.1 hI.1
    (fun a ha => (hI'.2 a ha).trans (hI.2 a ha).symm)
  obtain ⟨rfl, h⟩ := Sigma.mk.inj_iff.1 eq
  obtain rfl := eq_of_heq h
  exact hb

private theorem selector_heights (n : ℕ) (hn : 0 < n) (ε : ℝ) (hε : 0 < ε) :
    ∃ Y₀ : ℝ, ∀ Y ≥ Y₀,
      let z := Y ^ (ε / 5)
      let z' := z * Real.log Y ^ 2
      0 < z ∧ 2 * z ≤ z' ∧
      (Y ^ (ε / 6) ≤ Real.log (n * Real.exp z) ∧ Real.log (n * Real.exp z) ≤ Y ^ (ε / 4)) ∧
      (Y ^ (ε / 6) ≤ Real.log (n * Real.exp (z + z')) ∧
        Real.log (n * Real.exp (z + z')) ≤ Y ^ (ε / 4)) := by
  have he := (isLittleO_log_rpow_rpow_atTop (2 : ℝ) (show 0 < ε / 20 by linarith)).bound
    (c := (1 / 3 : ℝ)) (by positivity)
  have hlarge := (tendsto_rpow_atTop (show 0 < ε / 5 by linarith)).eventually_ge_atTop
    (Real.log (n : ℝ))
  obtain ⟨Y₀, H⟩ := Filter.eventually_atTop.1
    (he.and (hlarge.and (Filter.eventually_ge_atTop (Real.exp 2))))
  refine ⟨Y₀, fun Y hY => ?_⟩
  obtain ⟨hpow, hnz, hY2⟩ := H Y hY
  have hYpos : 0 < Y := lt_of_lt_of_le (Real.exp_pos _) hY2
  have hY1 : 1 ≤ Y := (Real.one_le_exp (by norm_num : (0:ℝ) ≤ 2)).trans hY2
  have hL : 2 ≤ Real.log Y := (Real.le_log_iff_exp_le hYpos).2 hY2
  have hnpos : 0 < (n : ℝ) := by exact_mod_cast hn
  have hnlog : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by exact_mod_cast hn)
  have hw : 0 < Y ^ (ε / 5) := Real.rpow_pos_of_pos hYpos _
  have hl : Y ^ (ε / 6) ≤ Y ^ (ε / 5) := Real.rpow_le_rpow_of_exponent_le hY1 (by linarith)
  have hbound : (Real.log Y)^2 ≤ (1/3:ℝ) * Y ^ (ε/20) := by
    simpa [Real.rpow_two, Real.norm_of_nonneg (sq_nonneg (Real.log Y)),
      Real.norm_of_nonneg (Real.rpow_nonneg hYpos.le (ε / 20))] using hpow
  have split : Y ^ (ε / 4) = Y ^ (ε / 5) * Y ^ (ε / 20) := by
    rw [← Real.rpow_add hYpos]; congr 1; ring
  have hzl : 2 * Y ^ (ε / 5) ≤ Y ^ (ε / 5) * Real.log Y ^ 2 := by
    calc 2 * Y ^ (ε / 5) = Y ^ (ε / 5) * 2 := mul_comm _ _
      _ ≤ Y ^ (ε / 5) * Real.log Y ^ 2 := mul_le_mul_of_nonneg_left (by nlinarith) hw.le
  have hge : 0 ≤ Y ^ (ε / 5) * Real.log Y ^ 2 := by positivity
  have hcap := mul_le_mul_of_nonneg_left hbound hw.le
  dsimp only
  rw [Real.log_mul hnpos.ne' (Real.exp_pos _).ne', Real.log_exp,
    Real.log_mul hnpos.ne' (Real.exp_pos _).ne', Real.log_exp, split]
  exact ⟨hw, hzl, ⟨by linarith, by linarith⟩, ⟨by linarith, by linarith⟩⟩

theorem rows_from_primitive_selector
    (box_of_S : ∃ C : ℝ, 0 < C ∧ ∀ ε τ K : ℝ, 0 < ε → ε ≤ 1 / 4 → 0 < τ → 1 ≤ K → ∃ Y₀ : ℝ, ∀ Y ≥ Y₀, ∀ (Q : ℝ) (N : ℕ) [NeZero N] (χ : DirichletCharacter ℂ N) (q : ℕ) (κ : ℕ → ℂ),
      Y ^ (ε / 6) ≤ Real.log Q → Real.log Q ≤ Y ^ (ε / 4) → GoodC Q χ → (∀ n : ℕ, χ (n : ZMod N) = κ n * J q n) →
      (∀ y ∈ Set.Icc Y (Y ^ K), ‖S ((Y ^ K) ^ 400) y q κ‖ ≤ y ^ (1 / 2 + τ) / 2) → Box Q C τ Y (Y ^ K) χ)
    (select : PrimitivePairSelector) :
    ∃ C : ℝ, 0 < C ∧ ∀ (M : ℕ), 0 < M → ∀ ε K : ℝ,
    0 < ε → ε < 1 / 52 → 1 ≤ K → ∃ Y₀ : ℝ, ∀ Y ≥ Y₀,
      let z := Y ^ (ε / 5)
      let z' := z * Real.log Y ^ 2
      ∃ q d : ℕ, Rows z z' q d ∧ 8 * M < q ∧
        GoodQ (8 * M) C (ε / 2) Y (Y ^ K) z q ∧
        GoodD (8 * M) C (ε / 2) Y (Y ^ K) z z' q d := by
  obtain ⟨C, hC, hbox⟩ := box_of_S
  refine ⟨C, hC, fun M hM ε K hε hε52 hK => ?_⟩
  have hn : 0 < 8 * M := by omega
  obtain ⟨Ys, hs⟩ := select M hM ε K hε hε52 hK
  obtain ⟨Yt, ht⟩ := selector_heights _ hn ε hε
  obtain ⟨Yb, hb⟩ := hbox ε (ε/2) K hε (by linarith) (by linarith) hK
  refine ⟨max (max Ys Yt) Yb, fun Y hY => ?_⟩
  have hYs := (le_max_left Ys Yt).trans ((le_max_left _ _).trans hY)
  have hYt := (le_max_right Ys Yt).trans ((le_max_left _ _).trans hY)
  have hYb := (le_max_right _ _).trans hY
  obtain ⟨q, hq, d, hd, hnq, hqraw, hdraw⟩ := hs Y hYs
  obtain ⟨hz, hzz, hqRange, hdRange⟩ := ht Y hYt
  have hR := rows_of_mem _ _ _ _ hz hzz hq hd
  have hmQ : 8 * M * q ≠ 0 := Nat.ne_of_gt (Nat.mul_pos hn hR.q_prime.pos)
  have hmD : 8 * M * q * d ≠ 0 := Nat.mul_ne_zero hmQ hR.d_prime.ne_zero
  refine ⟨q, d, hR, hnq, ?_, ?_⟩
  · intro ξ
    exact sample_box hmQ (fun N _ χ κ => hb Y hYb _ N χ q κ hqRange.1 hqRange.2) (hqraw ξ)
  · intro ξ i hi
    exact sample_box hmD (fun N _ χ κ => hb Y hYb _ N χ d κ hdRange.1 hdRange.2) (hdraw ξ i hi)

end QH

#print axioms QH.rows_from_primitive_selector
